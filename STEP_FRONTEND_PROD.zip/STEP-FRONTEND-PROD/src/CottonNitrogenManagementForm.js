import React, { useState, useEffect } from "react";
import axios from "axios";
import {
  Button,
  Checkbox,
  Container,
  FormControl,
  FormControlLabel,
  FormGroup,
  Grid,
  InputAdornment,
  InputLabel,
  MenuItem,
  Radio,
  RadioGroup,
  Select,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TextField,
  Typography,
  Card,
  CardContent,
  Paper,
} from "@mui/material";
import DeleteIcon from "@mui/icons-material/Delete";
import HighlightOffIcon from "@mui/icons-material/HighlightOff";
import DoneIcon from "@mui/icons-material/Done";
import EditIcon from "@mui/icons-material/Edit";
import EditOffIcon from "@mui/icons-material/EditOff";
import { useApplication } from "./ApplicationContext";

function CottonNitrogenManagementForm({ sectionData, hintText }) {
  //const [applicationType, setApplicationType] = useState("in-season");
  const [selectedCard, setSelectedCard] = useState(null);
  const [date, setDate] = useState("");
  const [amount, setAmount] = useState("");
  const [applications, setApplications] = useState([]);
  const teamName = localStorage.getItem("username");
  const [tableData, setTableData] = useState([]);
  const [subapplicationType, setSubApplicationType] = useState("");
  const [dateToday, setDateToday] = useState(new Date().toISOString());
  const token = localStorage.getItem("token");

  const {
    applicationType,
    setApplicationType,
    isApplicationTypeConfirmed,
    setIsApplicationTypeConfirmed,
  } = useApplication();

  const handleApplicationTypeConfirmation = (event) => {
    setIsApplicationTypeConfirmed(event.target.checked);
  };

  const handleConfirmApplicationType = () => {
    setIsApplicationTypeConfirmed(true);
    saveApplicationTypeConfirmationToBackend();
  };

  const saveApplicationTypeConfirmationToBackend = () => {
    const data = {
      teamName: teamName,
      applicationType: applicationType,
      isConfirmed: true,
    };

    axios
      .post("/api/saveCottonApplicationTypeConfirmation", data, {
        headers: {
          Authorization: `Bearer ${token}`, // Include the token in the Authorization header
        },
      })
      .then((response) => {
        console.log("Application type confirmation saved:", response);
      })
      .catch((error) => {
        console.error("Error saving application type confirmation:", error);
      });
  };

  const handleCardClick = (value) => {
    setApplicationType(value);
  };

  const inseasonOptions = ["Broadcast", "Banding", "Fertigation"];

  const controlledreleaseOptions = ["Broadcast", "Banding", "Incorporated"];

  const handleClick = (selected) => {
    if (selected === "Broadcast") setSubApplicationType("Broadcast");
    if (selected === "Banding") setSubApplicationType("banding");
    if (selected === "banding") setSubApplicationType("banding");
    if (selected === "Incorporated") setSubApplicationType("incorporated");
    if (selected === "Side-Dressed") setSubApplicationType("side-dressed");
    if (selected === "Liquidside-Dressing")
      setSubApplicationType("liquidside-dressing");
    if (selected === "Fertigation") setSubApplicationType("fertigation");
    if (selectedCard === selected) {
      setSelectedCard(null);
      setSubApplicationType("None");
    } else setSelectedCard(selected);
  };

  useEffect(() => {
    // Fetch data from the backend when the component mounts
    fetchCottonApplicationTypeConfirmation();
    fetchDataFromBackend();
  }, [applicationType]); // Fetch data whenever applicationType changes

  const fetchCottonApplicationTypeConfirmation = () => {
    axios
      .get(
        "/api/getCottonApplicationTypeConfirmation",
        {
          params: { teamName: teamName },
        },
        {
          headers: {
            Authorization: `Bearer ${token}`, // Include the token in the Authorization header
          },
        }
      )
      .then((response) => {
        if (response.status === 200 && response.data) {
          // Assuming response.data has the structure { applicationType, isConfirmed }
          setApplicationType(response.data.applicationType);
          setIsApplicationTypeConfirmed(response.data.isConfirmed);
        } else {
          console.error("Application type confirmation not found");
        }
      })
      .catch((error) => {
        console.error("Error fetching application type confirmation:", error);
      });
  };

  const handleDeleteApplication = (appId) => {
    axios
      .delete(`/api/deletecottonnitrogenApplication/${appId}`, {
        headers: {
          Authorization: `Bearer ${token}`, // Include the token in the Authorization header
        },
      })
      .then((response) => {
        if (response.status === 200) {
          // Application deleted successfully, now update the table data
          fetchDataFromBackend();
        } else {
          console.error("Failed to delete the application");
        }
      })
      .catch((error) => {
        console.error("Error deleting the application:", error);
      });
  };

  const fetchDataFromBackend = () => {
    // Make an API request to fetch data from the backend based on the application type
    axios
      .get(
        "/api/cottonfetchNitrogenManagementData",
        {
          params: {
            teamName,
            applicationType: applicationType,
          },
        },
        {
          headers: {
            Authorization: `Bearer ${token}`, // Include the token in the Authorization header
          },
        }
      )
      .then((response) => {
        if (response.status === 200) {
          // Set the retrieved data to the state variable
          setTableData(response.data);
        } else {
          console.error("Failed to fetch data from the backend");
        }
      })
      .catch((error) => {
        console.error("Error fetching data:", error);
      });
  };

  const handleAddApplication = async (e) => {
    e.preventDefault();
    // Create a new application object
    let newApplication;

    // Customize the object for in-season type
    newApplication = {
      applicationType: applicationType,
      date: date,
      amount: amount,
      placement: subapplicationType, // Initialize as an empty array
      teamName,
      applied: "no",
      dateToday: dateToday,
    };

    // Add the new application to the local state
    setApplications([...applications, newApplication]);

    // Clear the form fields
    setDate("");
    setAmount("");

    // Send the new application data to the backend
    sendApplicationDataToBackend(newApplication);
  };

  // Function to send application data to the backend using Axios
  const sendApplicationDataToBackend = (applicationData) => {
    axios
      .post("/api/cottonnitrogenmanagementsubmit", applicationData, {
        headers: {
          Authorization: `Bearer ${token}`, // Include the token in the Authorization header
        },
      })
      .then((response) => {
        if (response.status === 200) {
          console.log("Application data sent to the backend successfully");
          fetchDataFromBackend();
        } else {
          console.error("Failed to send application data to the backend");
        }
      })
      .catch((error) => {
        console.error("Error sending application data:", error);
      });
  };

  return (
    <Container>
      <form onSubmit={handleAddApplication}>
        <Typography variant="h6" gutterBottom>
          Add Application
        </Typography>

        <Grid container spacing={2}>
          <Grid item xs={6}>
            <Card
              onClick={() =>
                !isApplicationTypeConfirmed && handleCardClick("in-season")
              }
              sx={{
                cursor: !isApplicationTypeConfirmed ? "pointer" : "not-allowed",
                padding: "8px",
                backgroundColor:
                  applicationType === "in-season" ? "#fa4616" : "#D8D4D7",
                border: "2px solid #fa4616",
                borderRadius: "8px",
                opacity:
                  isApplicationTypeConfirmed && applicationType !== "in-season"
                    ? 0.5
                    : 1,
              }}
            >
              <CardContent>
                <Typography variant="body2">
                  In-season Fertilizer Application
                </Typography>
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={6}>
            <Card
              onClick={() =>
                !isApplicationTypeConfirmed &&
                handleCardClick("controlled-release")
              }
              sx={{
                cursor: !isApplicationTypeConfirmed ? "pointer" : "not-allowed",
                padding: "8px",
                backgroundColor:
                  applicationType === "controlled-release"
                    ? "#fa4616"
                    : "#D8D4D7",

                border: "2px solid #fa4616",
                borderRadius: "8px",
                opacity:
                  isApplicationTypeConfirmed &&
                  applicationType !== "controlled-release"
                    ? 0.5
                    : 1,
              }}
            >
              <CardContent>
                <Typography variant="body2">
                  Controlled-Release Fertilizer
                </Typography>
              </CardContent>
            </Card>
          </Grid>
        </Grid>

        <FormControlLabel
          control={
            <Checkbox
              checked={isApplicationTypeConfirmed}
              onChange={(event) => {
                handleApplicationTypeConfirmation(event);
                if (event.target.checked) {
                  handleConfirmApplicationType();
                }
              }}
            />
          }
          label="Confirm application type by ticking the checkbox (application type cannot be changed later once check box is ticked)"
        />

        {/* <Grid container spacing={2}>
        <Grid item xs={6}>
          <FormControl component="fieldset">
            <RadioGroup
              aria-label="applicationType"
              name="applicationType"
              value={applicationType}
              onChange={(e) => setApplicationType(e.target.value)}
            >
              <FormControlLabel
                value="in-season"
                control={<Radio />}
                label="In-season Fertilizer Application"
              />
            </RadioGroup>
          </FormControl>
        </Grid>
        <Grid item xs={6}>
          <FormControl component="fieldset">
            <RadioGroup
              aria-label="applicationType"
              name="applicationType"
              value={applicationType}
              onChange={(e) => setApplicationType(e.target.value)}
            >
              <FormControlLabel
                value="controlled-release"
                control={<Radio />}
                label="Controlled-Release Fertilizer"
              />
            </RadioGroup>
          </FormControl>
        </Grid>
      </Grid> */}

        {applicationType === "in-season" && (
          <>
            <p>
              In-season fertilizer applications of granular urea (46-0-0) or
              Urea Ammonium Nitrate are allowed. There will be no limit on the
              nitrogen rate, and you can choose the application timing using
              Broadcasting, Banding or Fertigation
            </p>

            <p>
              In case of a leaching rain event (determined by the project
              management team), an additional application of N at 30 lbs/ac will
              be allowed. Participating teams will be responsible to communicate
              their decision at least three days in advance.
            </p>

            <Grid item xs={12}>
              <Typography variant="h5">
                In season application methods:
              </Typography>
              <div style={{ display: "flex", flexWrap: "wrap" }}>
                {inseasonOptions.map((option) => (
                  <Card
                    key={option}
                    onClick={() => handleClick(option)}
                    sx={{
                      cursor: "pointer",
                      margin: "4px",
                      padding: "8px",
                      backgroundColor:
                        selectedCard === option ? "#fa4616" : "#D8D4D7",
                      border: "2px solid #fa4616",
                    }}
                  >
                    <CardContent>
                      <Typography variant="body2">{option}</Typography>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </Grid>
            <br></br>
            <Grid item xs={12}>
              <FormControl variant="outlined" fullWidth>
                <InputLabel id="subapplicationtype-label">
                  Application Type
                </InputLabel>
                <Select
                  labelId="subapplicationtype-label"
                  id="subapplicationtype"
                  label="Application Type"
                  value={subapplicationType}
                  onChange={(e) => setSubApplicationType(e.target.value)}
                  required
                >
                  <MenuItem value="">Select Application</MenuItem>
                  <MenuItem value="Broadcast">Broadcast</MenuItem>
                  <MenuItem value="banding">Banding</MenuItem>

                  <MenuItem value="fertigation">Fertigation</MenuItem>
                </Select>
              </FormControl>
            </Grid>
          </>
        )}
        {applicationType === "controlled-release" && (
          <>
            <p>
              Controlled Release Fertilizer Program: You have the flexibility to
              choose any Controlled Release Fertilizer (CRF) blend at any rate.
              All the CRF applications will be applied at planting.
            </p>

            <p>
              In case of a leaching rain event (determined by the project
              management team), an additional application of N at 30 lbs/ac will
              be allowed. Participating teams will be responsible to communicate
              their decision at least three days in advance.
            </p>
            <Grid item xs={12}>
              <Typography variant="h5">
                Controlled Release application methods:
              </Typography>
              <div style={{ display: "flex", flexWrap: "wrap" }}>
                {controlledreleaseOptions.map((option) => (
                  <Card
                    key={option}
                    onClick={() => handleClick(option)}
                    sx={{
                      cursor: "pointer",
                      margin: "4px",
                      padding: "8px",
                      backgroundColor:
                        selectedCard === option ? "#fa4616" : "#D8D4D7",
                      border: "2px solid #fa4616",
                    }}
                  >
                    <CardContent>
                      <Typography variant="body2">{option}</Typography>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </Grid>
            <br></br>
            <Grid item xs={12}>
              <FormControl variant="outlined" fullWidth>
                <InputLabel id="subapplicationtype-label">
                  Application Type
                </InputLabel>
                <Select
                  labelId="subapplicationtype-label"
                  id="subapplicationtype"
                  label="Application Type"
                  value={subapplicationType}
                  onChange={(e) => setSubApplicationType(e.target.value)}
                  required
                >
                  <MenuItem value="">Select Application Type</MenuItem>
                  <MenuItem value="Broadcast">Broadcast</MenuItem>
                  <MenuItem value="banding">Banding</MenuItem>
                  <MenuItem value="incorporated">Incorporated</MenuItem>
                  {/* <MenuItem value="fertigation">Fertigation</MenuItem> */}
                </Select>
              </FormControl>
            </Grid>
          </>
        )}
        <br></br>
        <TextField
          id={`${sectionData}-date-input`}
          label="Date"
          variant="outlined"
          fullWidth
          type="date"
          value={date}
          onChange={(e) => setDate(e.target.value)}
          InputLabelProps={{
            shrink: true,
          }}
          required
          // InputProps={{
          //   endAdornment: (
          //     <InputAdornment position="end">mm/dd/yy</InputAdornment>
          //   ),
          // }}
        />
        <br></br>
        <br></br>
        <TextField
          id={`${sectionData}-amount-input`}
          label="Amount (lbs/acre on N)"
          variant="outlined"
          fullWidth
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          helperText={hintText}
          required
        />
        <br></br>
        <br></br>
        <Button
          id={`n2-mgmnt-${sectionData}-add`}
          variant="contained"
          color="primary"
          type="submit"
        >
          Add Application
        </Button>
      </form>
      <br></br>
      <Typography variant="h6" gutterBottom>
        Application Data
      </Typography>
      <br></br>
      <TableContainer>
        <Table id={`table-n2-mgmnt-${sectionData}`} size="small">
          <TableHead>
            <TableRow>
              <TableCell>#</TableCell>
              <TableCell>Date</TableCell>
              <TableCell>Amount</TableCell>

              <TableCell>placement</TableCell>
              <TableCell>Applied</TableCell>
              <TableCell>
                <EditIcon />
              </TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {[...tableData]
              .sort((a, b) => new Date(a.date) - new Date(b.date))
              .map((app, index) => {
                // Format the date to display only the date part (YYYY-MM-DD)
                const formattedDate = new Date(app.date).toLocaleDateString();

                return (
                  <TableRow key={app.id}>
                    <TableCell>{index + 1}</TableCell>
                    <TableCell>{formattedDate}</TableCell>
                    <TableCell>{app.amount}</TableCell>
                    <TableCell>{app.placement}</TableCell>
                    <TableCell>
                      {app.applied === "no" ? (
                        <HighlightOffIcon />
                      ) : (
                        <DoneIcon />
                      )}
                    </TableCell>
                    <TableCell>
                      {" "}
                      <button>
                        {app.applied === "no" ? (
                          <DeleteIcon
                            onClick={() => handleDeleteApplication(app.id)}
                          />
                        ) : (
                          <EditOffIcon />
                        )}
                      </button>
                    </TableCell>
                    {/* {applicationType === "in-season" && (
                  <TableCell>{app.placement}</TableCell>
                )} */}
                  </TableRow>
                );
              })}
          </TableBody>
        </Table>
      </TableContainer>
    </Container>
  );
}

export default CottonNitrogenManagementForm;
