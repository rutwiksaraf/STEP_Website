import React, { useState, useEffect } from "react";
import axios from "axios";
import {
  Tabs,
  Tab,
  Paper,
  TextField,
  Button,
  Typography,
  TextareaAutosize,
  Grid,
  Container,
  List,
  Link,
  ListItemText,
  ListItem,
  Card, // Import Card from Material-UI
  CardContent, // Import CardContent from Material-UI
} from "@mui/material";

function CottonBulletin() {
  const [files, setFiles] = useState([]);
  const [fileInput, setFileInput] = useState(null);
  const [cottonteamfiles, setCottonTeamFiles] = useState([]);
  const teamName = localStorage.getItem("username");
  const token = localStorage.getItem("token");

  useEffect(() => {
    const fetchFiles = async () => {
      try {
        const response = await axios.get(
          `/api/listCottonTeamFiles/${teamName}`,
          {
            headers: {
              Authorization: `Bearer ${token}`, // Include the token in the Authorization header
            },
          }
        );
        setCottonTeamFiles(response.data.files);
      } catch (error) {
        console.error("Error fetching files:", error);
        // Handle error appropriately
      }
    };
    fetchFiles();
  }, []);

  useEffect(() => {
    // Fetch the list of files when the component mounts
    axios
      .get("/api/listcottonFiles", {
        headers: {
          Authorization: `Bearer ${token}`, // Include the token in the Authorization header
        },
      })
      .then((response) => {
        if (response.status === 200) {
          setFiles(response.data.files);
        } else {
          console.error("Failed to fetch files from the backend");
        }
      })
      .catch((error) => {
        console.error("Error fetching files:", error);
      });
  }, []);
  return (
    // <div>
    //   <h3>List of Files in Uploads Folder:</h3>
    //   <ul>
    //     {files.map((fileName, index) => (
    //       <li key={index}>
    //         {fileName}{" "}
    //         <a
    //           href={`/api/downloadFile/${fileName}`}
    //           download
    //         >
    //           Download
    //         </a>
    //       </li>
    //     ))}
    //   </ul>
    // </div>
    <Container maxWidth="sm">
      <Paper elevation={3} style={{ padding: "20px" }}>
        <Typography variant="h5" gutterBottom>
          List of Files in Uploads Folder:
        </Typography>
        <List>
          {files
            .filter((fileName) => fileName !== "metadata.json")
            .filter((fileName) => fileName !== "profile.jpg")
            .map((fileName, index) => (
              <ListItem key={index}>
                <ListItemText primary={fileName} />
                <Link href={`/api/downloadCottonFile/${fileName}`} download>
                  Download
                </Link>
              </ListItem>
            ))}
        </List>
        <List>
          {cottonteamfiles
            .filter((fileName) => fileName !== "metadata.json")
            .filter((fileName) => fileName !== "profile.jpg")
            .map((fileName, index) => (
              <ListItem key={index}>
                <ListItemText primary={fileName} />
                <Link
                  href={`/api/downloadCottonTeamFile/${teamName}/${fileName}`}
                  download
                >
                  Download
                </Link>
              </ListItem>
            ))}
        </List>
      </Paper>
    </Container>
  );
}
export default CottonBulletin;
