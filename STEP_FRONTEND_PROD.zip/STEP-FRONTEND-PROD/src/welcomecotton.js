import React, { useState, useEffect } from "react";
import {
  Tabs,
  Tab,
  Paper,
  Typography,
  Grid,
  Container,
  Card, // Import Card from Material-UI
  CardContent,
  Box,
  Avatar,
  FormControl,
  InputLabel,
  Input,
  FormHelperText,
  Button,
} from "@mui/material";
import CottonHybridForm from "./cottonHybridSelectionForm";
import CottonSeedingRateForm from "./CottonSeedingRateForm";
import CottonNitrogenManagementForm from "./CottonNitrogenManagementForm";
import CottonIrrigationManagementForm from "./CottonIrrigationManagement";
import CottonInsuranceSelectionForm from "./CottonInsuranceSelectionForm";
import CottonMarketingOptionsForm from "./CottonMarketingOptions";
import CottonGrowthRegulationForm from "./CottonGrowthRegulationForm";
import CottonBulletin from "./CottonBulletin";
import axios from "axios";
import cottonImage from "./cotton.jpg"; // Adjust './cotton.jpg' if your file structure is different

// import GrowthRegulationForm from "./GrowthRegulationForm"; // Import the Growth Regulation form

function WelcomeCotton() {
  // Retrieve stored user data from localStorage
  const teamName = localStorage.getItem("username");
  const username = localStorage.getItem("username");
  const [cottonfiles, setCottonFiles] = useState([]);
  // State to track the currently selected tab
  const [selectedTab, setSelectedTab] = useState(0);
  const [cornuser1, setCornuser1] = useState([]);
  const [teamMembers1, setTeamMembers1] = useState([]);
  const [cottoninsuranceLatest, setCottonInsuranceLatest] = useState([]);
  const [cottonmarketingLatest, setCottonMarketingLatest] = useState([]);
  const [selectedFile, setSelectedFile] = useState(null);
  const [profileImageUrl, setProfileImageUrl] = useState(null);
  const token = localStorage.getItem("token");

  const handleFileChange = (event) => {
    setSelectedFile(event.target.files[0]);
  };

  const handleUpload = async (event) => {
    event.preventDefault();

    if (!selectedFile) {
      alert("Please select a image to upload.");
      return;
    }

    const formData = new FormData();
    formData.append("file", selectedFile);
    formData.append("teamName", teamName);
    formData.append("cropType", "cotton");

    try {
      const response = await axios.post("/api/uploadimg", formData, {
        headers: {
          "Content-Type": "multipart/form-data",
          Authorization: `Bearer ${token}`,
        },
      });
      console.log(response.data);
      alert("File uploaded successfully!");
    } catch (error) {
      console.error("Error uploading file:", error);
      alert("Error uploading file.");
    }
  };

  useEffect(() => {
    if (selectedTab === 0 && cornuser1.length > 0) {
      fetchProfileImage();
    }
  }, [cornuser1]);

  const fetchProfileImage = () => {
    const imageUrl = `/uploads/${cornuser1[0].cropType}/${cornuser1[0].teamName}/profile.jpg`;
    fetch(imageUrl)
      .then((response) => {
        if (response.ok) {
          setProfileImageUrl(imageUrl);
        } else {
          setProfileImageUrl("/uploads/profile.jpg"); // Path to your generic image
        }
      })
      .catch(() => {
        setProfileImageUrl("/uploads/profile.jpg"); // Path to your generic image
      });
  };

  // Array of tab names (including the new "Growth Regulation" tab)

  const tabNames = [
    "Profile",
    "Hybrid Selection",
    "Seeding Rate",
    "Nitrogen Management",
    "Irrigation Management",
    "Insurance Selection",
    "Marketing Options",
    "Growth Regulator", // Add the new tab name here
    "Bulletin",
  ];

  // Function to handle tab selection
  const handleTabChange = (event, newValue) => {
    setSelectedTab(newValue);
  };

  useEffect(() => {
    // Fetch the list of files when the component mounts
    axios
      .get("/api/listcottonFiles", {
        headers: {
          Authorization: `Bearer ${token}`, // Include the token in the Authorization header
        },
      })
      .then((response) => {
        if (response.status === 200) {
          setCottonFiles(response.data.files);
        } else {
          console.error("Failed to fetch files from the backend");
        }
      })
      .catch((error) => {
        console.error("Error fetching files:", error);
      });
  }, []);

  useEffect(() => {
    // Fetch users for the Corn crop from the API
    axios
      .post(
        "/api/get_cotton_user",
        {
          teamName: username, // Send 'teamName' in the request body
        },
        {
          headers: {
            Authorization: `Bearer ${token}`, // Include the token in the Authorization header
          },
        }
      )
      .then((response) => {
        setCornuser1(response.data);
        console.log(response.data);
        console.log(cornuser1);
      })
      .catch((error) => {
        console.error("Error fetching Corn users data:", error);
      });
  }, []);

  useEffect(() => {
    if (selectedTab === 8 && cornuser1.length > 0) {
      // Assuming you have the team ID in cornuser[0].id
      axios
        .post(
          "/api/cottonTeamMembers",
          {
            id: cornuser1[0]?.id, // Access the team ID from cornuser[0]
          },
          {
            headers: {
              Authorization: `Bearer ${token}`, // Include the token in the Authorization header
            },
          }
        )
        .then((response) => {
          // Handle the fetched team members data, e.g., set it in state
          console.log(response.data);
          setTeamMembers1(response.data);
        })
        .catch((error) => {
          console.error("Error fetching team members:", error);
        });
    }
  }, [selectedTab, cornuser1]);

  useEffect(() => {
    // Fetch the list of files when the component mounts
    axios
      .get("/api/latestcottonInsuranceFiles", {
        headers: {
          Authorization: `Bearer ${token}`, // Include the token in the Authorization header
        },
      })
      .then((response) => {
        if (response.status === 200) {
          setCottonInsuranceLatest(response.data.files);
        } else {
          console.error("Failed to fetch files from the backend");
        }
      })
      .catch((error) => {
        console.error("Error fetching files:", error);
      });
  }, []);

  useEffect(() => {
    // Fetch the list of files when the component mounts
    axios
      .get("/api/latestcottonmarketingFiles", {
        headers: {
          Authorization: `Bearer ${token}`, // Include the token in the Authorization header
        },
      })
      .then((response) => {
        if (response.status === 200) {
          setCottonMarketingLatest(response.data.files);
        } else {
          console.error("Failed to fetch files from the backend");
        }
      })
      .catch((error) => {
        console.error("Error fetching files:", error);
      });
  }, []);

  return (
    <div>
      {/* <Paper
        elevation={2}
        style={{
          padding: 20,
          margin: 20,
        }}
      >
        <Typography variant="h5" gutterBottom>
          Welcome, {username}!
        </Typography>
      </Paper> */}
      {/* <div style={{ display: "flex" }}> */}
      <div>
        <Container maxWidth="78%">
          <Paper elevation={3} style={{ marginRight: "16px" }}>
            <Tabs
              value={selectedTab}
              onChange={handleTabChange}
              indicatorColor="secondary"
              // orientation="vertical" // Set tabs to be vertical
              textColor="primary"
              variant="fullWidth"
            >
              {tabNames.map((tab, index) => (
                <Tab
                  key={index}
                  label={tab}
                  sx={{ alignItems: "flex-start" }}
                />
              ))}
            </Tabs>
          </Paper>
          {/* Render the content for the selected tab */}
          <div>
            <Container maxWidth="100%">
              <p></p>
              {/* <Typography variant="h5" alignContent={"center"}>
                Welcome, {username}!
              </Typography> */}
              <br></br>
              <Typography variant="h5">{tabNames[selectedTab]}</Typography>
            </Container>
            {/* Content for other tabs (Hybrid Selection, Seeding Rate, etc.) */}
            {selectedTab === 0 && (
              <Container>
                <Paper elevation={3} style={{ padding: 20, margin: 20 }}>
                  <Box display="flex" alignItems="center">
                    <Avatar
                      alt="Profile Image"
                      src={profileImageUrl}
                      style={{ marginRight: 20 }}
                    />
                    <Typography variant="h4" gutterBottom>
                      Welcome, {username}!
                    </Typography>
                  </Box>
                </Paper>
                <p></p>
                <div>
                  <Avatar
                    alt="Profile Image"
                    src={profileImageUrl}
                    sx={{ width: 350, height: 350 }}
                    variant="rounded"
                  />
                  <p></p>
                  {/* <form onSubmit={handleUpload}>
                        <input type="file" onChange={handleFileChange} />
                        <p></p>
                        <button type="submit">Upload Profile Image</button>
                        <p></p>
                      </form> */}
                  <form
                    onSubmit={handleUpload}
                    style={{
                      display: "flex",
                      flexDirection: "column",
                      gap: "20px",
                      alignItems: "start",
                    }}
                  >
                    <FormControl>
                      <InputLabel htmlFor="file-input">
                        Profile Image
                      </InputLabel>
                      <p></p>
                      <Input
                        marginLeft="20px"
                        id="file-input"
                        type="file"
                        onChange={handleFileChange}
                      />
                      <FormHelperText>Select your profile image</FormHelperText>
                    </FormControl>

                    <Button variant="contained" color="primary" type="submit">
                      Upload Profile Image
                    </Button>
                  </form>
                </div>
                <Paper elevation={3} style={{ padding: 20, margin: 20 }}>
                  {cornuser1.length > 0 && (
                    <Grid container spacing={3}>
                      <Grid item xs={6}>
                        <Card>
                          <CardContent>
                            <Typography variant="h6">User Profile :</Typography>
                            <Typography>
                              Username/TeamName: {cornuser1[0].teamName}
                            </Typography>
                            <Typography>
                              Crop Type: {cornuser1[0].cropType}
                            </Typography>
                            <Typography>
                              Capitan First Name:{" "}
                              {cornuser1[0].captainFirstName}
                            </Typography>
                            <Typography>
                              Capitan Last Name: {cornuser1[0].captainLastName}
                            </Typography>

                            <Typography>
                              Address 1: {cornuser1[0].address1}
                            </Typography>
                            <Typography>
                              Address 2: {cornuser1[0].address2}
                            </Typography>
                          </CardContent>
                        </Card>
                      </Grid>
                      <Grid item xs={6}>
                        <Card>
                          <CardContent>
                            <Typography variant="h6">Location</Typography>
                            <Typography>City: {cornuser1[0].city}</Typography>
                            <Typography>State: {cornuser1[0].state}</Typography>
                            <Typography>
                              Zip Code: {cornuser1[0].zipCode}
                            </Typography>
                            <Typography>
                              Country: {cornuser1[0].country}
                            </Typography>
                          </CardContent>
                        </Card>
                      </Grid>
                      <Grid item xs={12}>
                        <Card>
                          <CardContent>
                            <Typography variant="h6">
                              Contact Information
                            </Typography>
                            <Typography>Email: {cornuser1[0].email}</Typography>
                            <Typography>Phone: {cornuser1[0].phone}</Typography>
                          </CardContent>
                        </Card>
                      </Grid>
                    </Grid>
                  )}

                  {teamMembers1.length > 0 && (
                    <Paper elevation={3} style={{ marginTop: 20, padding: 20 }}>
                      <Typography variant="h5" gutterBottom>
                        Team Members
                      </Typography>
                      {teamMembers1.map((member, index) => (
                        <Card key={index} style={{ marginBottom: 10 }}>
                          <CardContent>
                            <Typography variant="h6">
                              Team Member {index + 1}
                            </Typography>
                            <Typography>Name: {member.name}</Typography>
                            <Typography>Email: {member.email}</Typography>
                          </CardContent>
                        </Card>
                      ))}
                    </Paper>
                  )}
                </Paper>
              </Container>
            )}
            {selectedTab === 1 && (
              <Container component="main" maxWidth="90%">
                <div>
                  {/* <h3>Hybrid Selection</h3> */}
                  <p>
                    Hybrid selection is a critical step in crop management. It
                    involves choosing the most suitable hybrid varieties for
                    your farming conditions and goals.
                  </p>
                  <p>
                    You can choose one of the default hybrids listed below or
                    source your own seed. If sourcing your own seed, 15 lbs of
                    seed must be delivered to the North Florida Research and
                    Education Center by March 20th. You must provide
                    documentation of the retail price for any seed that you
                    source.
                  </p>
                  <CottonHybridForm />
                </div>
              </Container>
            )}

            {/* Content for other tabs (Seeding Rate, Nitrogen Management, etc.) */}
            {selectedTab === 2 && (
              <Container component="main" maxWidth="90%">
                <div>
                  <p>
                    Choose any plant population (seeding rate per acre) between
                    24,000 and 40,000 seeds per acre, in increments of 2,000
                    seeds per acre.
                  </p>
                  <CottonSeedingRateForm />
                </div>
              </Container>
            )}
            {/* Content for other tabs (Nitrogen Management, Irrigation Management, etc.) */}
            {selectedTab === 3 && (
              <Container component="main" maxWidth="90%">
                <div>
                  <p>
                    All the plots will receive 13 gals/ac (~ 30-40 lbs/ac of N)
                    of startup fertilizer (23-9-0) at the time of planting. You
                    can choose in-season fertilizer applications of dry ammonium
                    nitrate (34-0-0) and UAN 28% (28-0-0-5), or a controlled
                    release fertilizer program.
                  </p>
                  <CottonNitrogenManagementForm />
                </div>
              </Container>
            )}

            {/* Content for other tabs (Irrigation Management, Insurance Selection, etc.) */}
            {selectedTab === 4 && (
              <Container component="main" maxWidth="90%">
                <div>
                  <CottonIrrigationManagementForm />
                </div>
              </Container>
            )}

            {/* Content for other tabs (Insurance Selection, Marketing Options, etc.) */}
            {selectedTab === 5 && (
              <Container component="main" maxWidth="90%">
                <div>
                  <p>
                    You must select crop insurance at the 50% level or above.
                    Crop insurance options include the following:
                  </p>
                  <ul>
                    <li>
                      <strong>Yield Protection:</strong> This option provides
                      protection based on your crop's yield.
                    </li>
                    <li>
                      <strong>Revenue Protection:</strong> This option provides
                      protection based on both yield and revenue.
                    </li>
                  </ul>
                  <p>
                    You may choose the following coverage levels: Catastrophic
                    (minimum) up to 85% coverage level with unit options.
                    Insurance selections must be made by March 31st. Once your
                    insurance choice has been submitted, it cannot be changed
                    for this year’s contest.
                  </p>
                  <p>
                    We provide insurance quotes in advance to help you make an
                    informed decision.
                  </p>
                  <div style={{ display: "flex", flexWrap: "wrap" }}>
                    <div style={{ flex: 3, minWidth: "400px" }}>
                      <CottonInsuranceSelectionForm />
                    </div>
                    <div
                      style={{
                        flex: 1,
                        border: "1px solid #ccc",
                        padding: "10px",
                        // minHeight: "400px",
                        maxHeight: "400px", // Set a maximum height for the div
                        overflow: "auto", // Add scrollbars if the content exceeds the height
                        minWidth: "300px", // Use a minimum width
                        backgroundImage: `url(${cottonImage})`, // Replace 'imageUrl' with your image URL
                        backgroundSize: "cover", // Ensure the background image covers the entire div
                        backgroundPosition: "center", // Center the background image
                        backgroundRepeat: "no-repeat", // Prevent the background image from repeating
                      }}
                    >
                      <h3>List of Insurance Files:</h3>
                      {cottoninsuranceLatest
                        .filter((fileName) => fileName !== "metadata.json")
                        .filter((fileName) => fileName !== "profile.jpg")
                        .length > 0 ? (
                        <ul>
                          {cottoninsuranceLatest
                            .filter((fileName) => fileName !== "metadata.json")
                            .filter((fileName) => fileName !== "profile.jpg")
                            .map((fileName, index) => (
                              <li
                                key={index}
                                style={{
                                  backgroundColor: "rgba(255, 255, 255, 0.8)",
                                }}
                              >
                                {" "}
                                {/* Semi-transparent background for text readability */}
                                <p>File Name: {fileName.originalFileName}</p>
                                <p>
                                  Upload Date:{" "}
                                  {new Date(
                                    fileName.uploadDate
                                  ).toLocaleDateString()}
                                </p>
                                <a
                                  href={`/api/downloadFile/${fileName.originalFileName}`}
                                  download
                                >
                                  Download
                                </a>
                              </li>
                            ))}
                        </ul>
                      ) : (
                        <p
                          style={{
                            backgroundColor: "rgba(255, 255, 255, 0.8)",
                          }}
                        >
                          No latest files.
                        </p> // Semi-transparent background for text readability
                      )}
                    </div>

                    {/* <div
                      style={{
                        flex: 1,
                        border: "1px solid #ccc",
                        padding: "10px",
                        maxHeight: "400px", // Set a maximum height for the div
                        overflow: "auto", // Add scrollbars if the content exceeds the height
                        minWidth: "300px", // Use a minimum width
                        backgroundImage: "url('imageUrl')", // Replace 'imageUrl' with your image URL
                        backgroundSize: "cover", // Ensure the background image covers the entire div
                        backgroundPosition: "center", // Center the background image
                        backgroundRepeat: "no-repeat",
                      }}
                    >
                      <h3>List of Insurance Files:</h3>

                      {cottoninsuranceLatest
                        .filter((fileName) => fileName !== "metadata.json")
                        .filter((fileName) => fileName !== "profile.jpg")
                        .length > 0 ? (
                        <ul>
                          cottoninsuranceLatest .filter((fileName) => fileName
                          !== "metadata.json") .filter((fileName) => fileName
                          !== "profile.jpg") .map((fileName, index) => (
                          <li key={index}>
                            <p>File Name: {fileName.originalFileName}</p>
                            <p>
                              Upload Date:{" "}
                              {new Date(
                                fileName.uploadDate
                              ).toLocaleDateString()}
                            </p>

                            <a
                              href={`/api/downloadFile/${fileName.originalFileName}`}
                              download
                            >
                              Download
                            </a>
                          </li>
                          ))}
                        </ul>
                      ) : (
                        <p>No latest files.</p>
                      )}
                    </div>
                  </div>
                </div> */}
                  </div>
                </div>
              </Container>
            )}
            {selectedTab === 6 && (
              <Container component="main">
                <div>
                  <div style={{ display: "flex", flexWrap: "wrap" }}>
                    <div style={{ flex: 3, minWidth: "400px" }}>
                      <p>
                        Each team must make marketing selections for the
                        simulated 1,000-acre cotton farm. The total number of
                        pounds marketed will be the average yield per acre
                        harvested from your research plots multiplied by 1,000
                        acres. Simulated delivery of the harvested cotton is
                        assumed to take place on the research plot harvest date.
                      </p>

                      <p>
                        You may choose forward contracts for specific dates and
                        quantities between the competition start date and a
                        specified deadline. The local basis for forward
                        contracts (relative to a relevant price) will be posted
                        weekly on this webpage. You can select multiple
                        contracts, but the total amount contracted may not
                        exceed a certain limit. Your previous contracts will be
                        shown in the table below.
                      </p>

                      <p>
                        For each forward contract selected, you must go to the
                        table and complete the contract by locking in the price
                        on the chosen date. If a contract is not completed by
                        the specified deadline, we will use the relevant closing
                        price on that date to complete the contract.
                      </p>

                      <p>
                        The grower’s delivered price on a forward contract will
                        be the sum of the local basis on the date you initiate
                        the contract plus the relevant closing price on the date
                        you complete the contract. A hauling fee will be charged
                        for delivery to a designated buying point.
                      </p>

                      <p>
                        Any pounds of cotton that are not sold through contracts
                        will be assigned a spot price on the harvest date.
                        Please be aware that there is a penalty for
                        overcontracting beyond the specified limit.
                      </p>
                    </div>
                    <p></p>
                    <div
                      style={{
                        flex: 1,
                        border: "1px solid #ccc",
                        padding: "10px",
                        maxHeight: "400px", // Set a maximum height for the div
                        overflow: "auto", // Add scrollbars if the content exceeds the height
                        minWidth: "250px", // Use a minimum width
                        backgroundImage: `url(${cottonImage})`, // Replace 'imageUrl' with your image URL
                        backgroundSize: "cover", // Ensure the background image covers the entire div
                        backgroundPosition: "center", // Center the background image
                        backgroundRepeat: "no-repeat",
                      }}
                    >
                      <h3>List of Marketing Files:</h3>
                      {cottonmarketingLatest
                        .filter((fileName) => fileName !== "metadata.json")
                        .filter((fileName) => fileName !== "profile.jpg")
                        .length > 0 ? (
                        <ul>
                          {cottonmarketingLatest
                            .filter((fileName) => fileName !== "metadata.json")
                            .filter((fileName) => fileName !== "profile.jpg")
                            .map((fileName, index) => (
                              <li
                                style={{
                                  backgroundColor: "rgba(255, 255, 255, 0.8)",
                                }}
                                key={index}
                              >
                                {/* {fileName}{" "} */}
                                <p>File Name: {fileName.originalFileName}</p>
                                <p>
                                  Upload Date:{" "}
                                  {new Date(
                                    fileName.uploadDate
                                  ).toLocaleDateString()}
                                </p>

                                <a
                                  href={`/api/downloadFile/${fileName.originalFileName}`}
                                  download
                                >
                                  Download
                                </a>
                              </li>
                            ))}
                        </ul>
                      ) : (
                        <p
                          style={{
                            backgroundColor: "rgba(255, 255, 255, 0.8)",
                          }}
                        >
                          No latest files.
                        </p> // Semi-transparent background for text readability
                      )}
                    </div>
                  </div>
                  <CottonMarketingOptionsForm />
                </div>
              </Container>
            )}

            {/* Content for the new "Growth Regulation" tab */}
            {selectedTab === 7 && (
              <Container component="main">
                <div>
                  <p>
                    Growth regulation is essential for optimizing cotton crop
                    yield and quality. You can manage growth through various
                    practices and treatments.
                  </p>
                  <p>
                    Growth Regulator: Pix (Mepiquat Chloride) and Stance will be
                    provided, and you can apply them at any rate as needed.
                  </p>
                  {/* Include any relevant form or input for managing growth regulators if needed */}
                  {/* <GrowthRegulationForm /> */}
                  <CottonGrowthRegulationForm />
                </div>
              </Container>
            )}

            {selectedTab === 8 && (
              <Container component="main" maxWidth="90%">
                <CottonBulletin />
              </Container>
            )}
          </div>
        </Container>
      </div>
    </div>
  );
}

export default WelcomeCotton;
