/* Import your CSS file for styling, assuming it's named RegistrationForm.css */
import "./App.css";

import React from "react";
import {
  Button,
  Card,
  CardContent,
  TextField,
  Container,
  Grid,
  Typography,
} from "@mui/material";

function RegistrationForm({
  formData,
  registrationMessage,
  handleChange,
  handleTeamMemberChange,
  handleAddTeamMember,
  handleDeleteTeamMember,
  handleSubmit,
  redirecting,
}) {
  if (redirecting) {
    return (
      <div className="App">
        <h2 className="success-message">{registrationMessage}</h2>
        <h4>Redirecting to the login page...</h4>
      </div>
    );
  }

  return (
    <Container component="main">
      <div className="registration-container">
        <div className="registration-form">
          <Typography
            variant="h4"
            gutterBottom
            className="form-heading"
            color={"#0021A5"}
          >
            Florida Step Team Registration
          </Typography>

          {registrationMessage && (
            <h3 className="success-message">{registrationMessage}</h3>
          )}

          <form onSubmit={handleSubmit}>
            <Grid container spacing={2}>
              <Grid item xs={12}>
                <Typography variant="subtitle1" gutterBottom>
                  Crop Type:
                </Typography>
                <Grid container spacing={2}>
                  <Grid item xs={6}>
                    <Card
                      onClick={() =>
                        handleChange({
                          target: { name: "cropType", value: "corn" },
                        })
                      }
                      elevation={formData.cropType === "corn" ? 5 : 1}
                      style={{
                        cursor: "pointer",
                        backgroundColor:
                          formData.cropType === "corn" ? "#FA4616" : "white",
                      }}
                    >
                      <CardContent>
                        <Typography variant="h6">Corn</Typography>
                      </CardContent>
                    </Card>
                  </Grid>
                  <Grid item xs={6}>
                    <Card
                      onClick={() =>
                        handleChange({
                          target: { name: "cropType", value: "cotton" },
                        })
                      }
                      elevation={formData.cropType === "cotton" ? 5 : 1}
                      style={{
                        cursor: "pointer",
                        backgroundColor:
                          formData.cropType === "cotton" ? "#FA4616" : "white",
                      }}
                    >
                      <CardContent>
                        <Typography variant="h6">Cotton</Typography>
                      </CardContent>
                    </Card>
                  </Grid>
                </Grid>
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Team Name"
                  name="teamName"
                  value={formData.teamName}
                  onChange={handleChange}
                  required
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Password"
                  name="password"
                  type="password"
                  value={formData.password}
                  onChange={handleChange}
                  required
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  label="First Name (Team Captain)"
                  name="captainFirstName"
                  value={formData.captainFirstName}
                  onChange={handleChange}
                  required
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  label="Last Name (Team Captain)"
                  name="captainLastName"
                  value={formData.captainLastName}
                  onChange={handleChange}
                  required
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Address"
                  name="address1"
                  value={formData.address1}
                  onChange={handleChange}
                  required
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Address Line 2"
                  name="address2"
                  value={formData.address2}
                  onChange={handleChange}
                  required
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  label="City"
                  name="city"
                  value={formData.city}
                  onChange={handleChange}
                  required
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  label="State / Province / Region"
                  name="state"
                  value={formData.state}
                  onChange={handleChange}
                  required
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  label="ZIP / Postal Code"
                  name="zipCode"
                  value={formData.zipCode}
                  onChange={handleChange}
                  required
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  label="Country"
                  name="country"
                  value={formData.country}
                  onChange={handleChange}
                  required
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Email (Team Captain)"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  required
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Phone (Team Captain)"
                  name="phone"
                  value={formData.phone}
                  onChange={handleChange}
                  required
                />
              </Grid>
              <Grid item xs={12}>
                <Typography variant="h6" gutterBottom>
                  Team Members:
                </Typography>
                {formData.teamMembers.map((member, index) => (
                  <div key={index} className="team-member">
                    <TextField
                      fullWidth
                      label={`Team Member ${index + 1} Name`}
                      value={member.name}
                      onChange={(e) =>
                        handleTeamMemberChange(index, "name", e.target.value)
                      }
                    />
                    <TextField
                      fullWidth
                      label={`Team Member ${index + 1} Email`}
                      value={member.email}
                      onChange={(e) =>
                        handleTeamMemberChange(index, "email", e.target.value)
                      }
                    />
                    <Button
                      type="button"
                      onClick={() => handleDeleteTeamMember(index)}
                      variant="outlined"
                      color="error"
                      style={{ width: "50%" }}
                    >
                      Delete team member
                    </Button>
                    <p></p>
                  </div>
                ))}
                <Button
                  mb={5}
                  id="team"
                  type="button"
                  onClick={handleAddTeamMember}
                  variant="outlined"
                  color="secondary"
                  style={{ width: "50%" }}
                >
                  Add Team Member
                </Button>
              </Grid>
            </Grid>
            <p></p>

            <Grid item xs={12}>
              <Button
                id="submit"
                type="submit"
                variant="contained"
                color="secondary"
              >
                Register
              </Button>
            </Grid>
          </form>
        </div>
      </div>
    </Container>
  );
}
export default RegistrationForm;

// import React, { useState } from "react";
// import { BrowserRouter as Router, Route, Switch } from "react-router-dom";

// import "./App.css";
// import {
//   Button,
//   Card,
//   CardContent,
//   TextField,
//   Container,
//   Grid,
//   Typography,
//   FormControl, // Import FormControl
//   InputLabel, // Import InputLabel
//   Select, // Import Select
//   MenuItem, // Import MenuItem
// } from "@mui/material";

// function RegistrationForm({
//   formData,
//   registrationMessage,
//   handleChange,
//   handleTeamMemberChange,
//   handleAddTeamMember,
//   handleDeleteTeamMember,
//   handleSubmit,
//   redirecting,
// }) {
//   if (redirecting) {
//     return (
//       <div className="App">
//         <h2 className="success-message">{registrationMessage}</h2>
//         <h4>Redirecting to the login page...</h4>
//       </div>
//     );
//   }
//   return (
//     <Container component="main" maxWidth="xs">
//       <div className="App">
//         <Typography
//           variant="h4"
//           gutterBottom
//           style={{ fontWeight: "bold", color: "#0021A5", border: "3%" }}
//         >
//           Florida Step Team Registration
//         </Typography>

//         {registrationMessage && (
//           <h3 className="success-message">{registrationMessage}</h3>
//         )}

//         <form onSubmit={handleSubmit}>
//           <Grid container spacing={2}>
//             {/* <Grid item xs={12}>
//               <FormControl fullWidth>
//                 <InputLabel>Crop Type</InputLabel>
//                 <Select
//                   name="cropType"
//                   value={formData.cropType}
//                   onChange={handleChange}
//                   required
//                 >
//                   <MenuItem value="corn">Corn</MenuItem>
//                   <MenuItem value="cotton">Cotton</MenuItem>
//                 </Select>
//               </FormControl>
//             </Grid> */}
//             <Grid item xs={12}>
//               <Typography variant="subtitle1" gutterBottom>
//                 Crop Type:
//               </Typography>
//               <Grid container spacing={2}>
//                 <Grid item xs={6}>
//                   <Card
//                     onClick={() =>
//                       handleChange({
//                         target: { name: "cropType", value: "corn" },
//                       })
//                     }
//                     elevation={formData.cropType === "corn" ? 5 : 1}
//                     style={{
//                       cursor: "pointer",
//                       backgroundColor:
//                         formData.cropType === "corn" ? "#FA4616" : "white",
//                     }}
//                   >
//                     <CardContent>
//                       <Typography variant="h6">Corn</Typography>
//                     </CardContent>
//                   </Card>
//                 </Grid>
//                 <Grid item xs={6}>
//                   <Card
//                     onClick={() =>
//                       handleChange({
//                         target: { name: "cropType", value: "cotton" },
//                       })
//                     }
//                     elevation={formData.cropType === "cotton" ? 5 : 1}
//                     style={{
//                       cursor: "pointer",
//                       backgroundColor:
//                         formData.cropType === "cotton" ? "#FA4616" : "white",
//                     }}
//                   >
//                     <CardContent>
//                       <Typography variant="h6">Cotton</Typography>
//                     </CardContent>
//                   </Card>
//                 </Grid>
//               </Grid>
//             </Grid>
//             <Grid item xs={12}>
//               <TextField
//                 fullWidth
//                 label="Team Name"
//                 name="teamName"
//                 value={formData.teamName}
//                 onChange={handleChange}
//                 required
//               />
//             </Grid>
//             <Grid item xs={12}>
//               <TextField
//                 fullWidth
//                 label="Password"
//                 name="password"
//                 type="password"
//                 value={formData.password}
//                 onChange={handleChange}
//                 required
//               />
//             </Grid>
//             <Grid item xs={12} sm={6}>
//               <TextField
//                 fullWidth
//                 label="First Name (Team Captain)"
//                 name="captainFirstName"
//                 value={formData.captainFirstName}
//                 onChange={handleChange}
//                 required
//               />
//             </Grid>
//             <Grid item xs={12} sm={6}>
//               <TextField
//                 fullWidth
//                 label="Last Name (Team Captain)"
//                 name="captainLastName"
//                 value={formData.captainLastName}
//                 onChange={handleChange}
//                 required
//               />
//             </Grid>
//             <Grid item xs={12}>
//               <TextField
//                 fullWidth
//                 label="Address"
//                 name="address1"
//                 value={formData.address1}
//                 onChange={handleChange}
//                 required
//               />
//             </Grid>
//             <Grid item xs={12}>
//               <TextField
//                 fullWidth
//                 label="Address Line 2"
//                 name="address2"
//                 value={formData.address2}
//                 onChange={handleChange}
//               />
//             </Grid>
//             <Grid item xs={12} sm={6}>
//               <TextField
//                 fullWidth
//                 label="City"
//                 name="city"
//                 value={formData.city}
//                 onChange={handleChange}
//               />
//             </Grid>
//             <Grid item xs={12} sm={6}>
//               <TextField
//                 fullWidth
//                 label="State / Province / Region"
//                 name="state"
//                 value={formData.state}
//                 onChange={handleChange}
//               />
//             </Grid>
//             <Grid item xs={12} sm={6}>
//               <TextField
//                 fullWidth
//                 label="ZIP / Postal Code"
//                 name="zipCode"
//                 value={formData.zipCode}
//                 onChange={handleChange}
//               />
//             </Grid>
//             <Grid item xs={12} sm={6}>
//               <TextField
//                 fullWidth
//                 label="Country"
//                 name="country"
//                 value={formData.country}
//                 onChange={handleChange}
//               />
//             </Grid>
//             <Grid item xs={12}>
//               <TextField
//                 fullWidth
//                 label="Email (Team Captain)"
//                 name="email"
//                 value={formData.email}
//                 onChange={handleChange}
//                 required
//               />
//             </Grid>
//             <Grid item xs={12}>
//               <TextField
//                 fullWidth
//                 label="Phone (Team Captain)"
//                 name="phone"
//                 value={formData.phone}
//                 onChange={handleChange}
//                 required
//               />
//             </Grid>

//             <Grid item xs={12}>
//               <Typography variant="h6" gutterBottom>
//                 Team Members:
//               </Typography>
//               {formData.teamMembers.map((member, index) => (
//                 <div key={index} className="team-member">
//                   <TextField
//                     fullWidth
//                     value={member.name}
//                     onChange={(e) =>
//                       handleTeamMemberChange(index, "name", e.target.value)
//                     }
//                     placeholder={`Team Member ${index + 1} Name`}
//                   />
//                   <TextField
//                     fullWidth
//                     value={member.email}
//                     onChange={(e) =>
//                       handleTeamMemberChange(index, "email", e.target.value)
//                     }
//                     placeholder={`Team Member ${index + 1} Email`}
//                   />
//                   <Button
//                     type="button"
//                     onClick={() => handleDeleteTeamMember(index)}
//                     variant="outlined"
//                     color="error"
//                   >
//                     Delete
//                   </Button>
//                 </div>
//               ))}
//               <Button
//                 mb={5}
//                 type="button"
//                 onClick={handleAddTeamMember}
//                 variant="outlined"
//                 color="secondary"
//               >
//                 Add Team Member
//               </Button>
//             </Grid>
//           </Grid>

//           <Button type="submit" variant="contained" color="secondary">
//             Register
//           </Button>
//         </form>
//       </div>
//     </Container>
//   );
// }
