import React, { useState, useEffect } from "react";
import HybridForm from "./HybridSelecionForm";
import SeedingRateForm from "./SeedingRateForm";
import NitrogenManagementForm from "./NitrogenManagementForm";
import IrrigationManagementForm from "./IrrigationManagementForm";
import InsuranceSelectionForm from "./InsuranceSelectionForm";
import MarketingOptionsForm from "./MarketingOptionsForm";
import CornBulletin from "./Bulletin";
import UserDetails from "./UserDetails";
import axios from "axios";
import { CardMedia } from "@mui/material";
import cornImage from "./cornimg.jpg";
import {
  Avatar,
  Tabs,
  Tab,
  Paper,
  TextField,
  Button,
  Typography,
  TextareaAutosize,
  Grid,
  Container,
  Card, // Import Card from Material-UI
  CardContent, // Import CardContent from Material-UI
  Box,
  FormControl,
  InputLabel,
  Input,
  FormHelperText,
} from "@mui/material";
import { CenterFocusStrong } from "@mui/icons-material";

function Welcome() {
  // Retrieve stored user data from localStorage

  const username = localStorage.getItem("username");
  const teamName = localStorage.getItem("username");
  const token = localStorage.getItem("token");

  // State to track the currently selected tab
  const [selectedTab, setSelectedTab] = useState(0);

  const [files, setFiles] = useState([]);
  const [insurance, setInsurance] = useState([]);
  const [marketing, setMarketing] = useState([]);
  const [insuranceLatest, setInsuranceLatest] = useState([]);
  const [marketingLatest, setMarketingLatest] = useState([]);
  const [cornuser, setCornuser] = useState([]);
  const [teamMembers, setTeamMembers] = useState([]);
  const [files1, setFiles1] = useState([]);
  const [fileInput, setFileInput] = useState(null);

  const [selectedFile, setSelectedFile] = useState(null);
  const [profileImageUrl, setProfileImageUrl] = useState(null);

  const handleFileChange = (event) => {
    setSelectedFile(event.target.files[0]);
  };

  const handleUpload = async (event) => {
    event.preventDefault();

    if (!selectedFile) {
      alert("Please select a image to upload.");
      return;
    }

    const formData = new FormData();
    formData.append("file", selectedFile);
    formData.append("teamName", teamName);
    formData.append("cropType", "corn");

    try {
      const response = await axios.post("/api/uploadimg", formData, {
        headers: {
          "Content-Type": "multipart/form-data",
          Authorization: `Bearer ${token}`,
        },
      });
      console.log(response.data);
      alert("File uploaded successfully!");
    } catch (error) {
      console.error("Error uploading file:", error);
      alert("Error uploading file.");
    }
  };

  useEffect(() => {
    fetchCornUsers();
  }, []);

  useEffect(() => {
    if (selectedTab === 0 && cornuser.length > 0) {
      fetchProfileImage();
    }
  }, [cornuser]);
  // const fetchProfileImage = () => {
  //   const imageUrl = `/uploads/${cornuser[0].cropType}/${cornuser[0].teamName}/profile.jpg`;
  //   fetch(imageUrl)
  //     .then((response) => {
  //       if (response.ok) {
  //         setProfileImageUrl(imageUrl);
  //       } else {
  //         setProfileImageUrl("/uploads/profile.jpg"); // Path to your generic image
  //       }
  //     })
  //     .catch(() => {
  //       setProfileImageUrl("/uploads/profile.jpg"); // Path to your generic image
  //     });
  // };

  const fetchProfileImage = () => {
    const profileImageUrlEndpoint = `/api/getProfileImageUrl/${cornuser[0].cropType}/${cornuser[0].teamName}`;

    fetch(profileImageUrlEndpoint, {
      headers: {
        Authorization: `Bearer ${token}`, // Include the token in the Authorization header
      },
    })
      .then((response) => response.text()) // Assuming the response is plain text containing the image URL
      .then((imageUrl) => {
        setProfileImageUrl(imageUrl);
      })
      .catch(() => {
        setProfileImageUrl("/uploads/profile.jpg"); // Path to your generic image
      });
  };

  useEffect(() => {
    // Fetch the list of files when the component mounts
    axios
      .get("/api/listFiles", {
        headers: {
          Authorization: `Bearer ${token}`, // Include the token in the Authorization header
        },
      })
      .then((response) => {
        if (response.status === 200) {
          setFiles(response.data.files);
        } else {
          console.error("Failed to fetch files from the backend");
        }
      })
      .catch((error) => {
        console.error("Error fetching files:", error);
      });
  }, []);

  const fetchCornUsers = () => {
    axios
      .post(
        "/api/get_corn_user",
        {
          teamName: teamName, // Send 'teamName' in the request body
        },
        {
          headers: {
            Authorization: `Bearer ${token}`, // Include the token in the Authorization header
          },
        }
      )
      .then((response) => {
        setCornuser(response.data);
        // console.log(response.data);
        // console.log(cornuser);
      })
      .catch((error) => {
        console.error("Error fetching Corn users data:", error);
      });
  };

  // Call the function to fetch team members data when needed, for example, in a useEffect.

  // useEffect(() => {
  // Fetch users for the Corn crop from the API
  // const fetchTeamMembers = () => {
  // axios
  //   .post("/api/cornTeamMembers", {
  //     params: {
  //       id: cornuser[0].id, // Assuming you have the team ID in cornuser[0].id
  //     },
  //   })
  //   .then((response) => {
  //     // Handle the data you received from the backend
  //     const teamMembers = response.data;
  //     console.log("Team Members Data:", teamMembers);
  //     // You can set the data in your component's state or use it as needed.
  //   })
  //   .catch((error) => {
  //     console.error("Error fetching team members data:", error);
  //   });
  // };
  // }, [cornuser]);

  useEffect(() => {
    if (selectedTab === 7 && cornuser.length > 0) {
      // Assuming you have the team ID in cornuser[0].id
      axios
        .post(
          "/api/cornTeamMembers",
          {
            id: cornuser[0]?.id, // Access the team ID from cornuser[0]
          },
          {
            headers: {
              Authorization: `Bearer ${token}`, // Include the token in the Authorization header
            },
          }
        )
        .then((response) => {
          // Handle the fetched team members data, e.g., set it in state
          console.log(response.data);
          setTeamMembers(response.data);
        })
        .catch((error) => {
          console.error("Error fetching team members:", error);
        });
    }
  }, [selectedTab, cornuser]);

  useEffect(() => {
    console.log(cornuser);
  }, [cornuser]);

  useEffect(() => {
    // Fetch the list of files when the component mounts
    axios
      .get("/api/listInsuranceFiles", {
        headers: {
          Authorization: `Bearer ${token}`, // Include the token in the Authorization header
        },
      })
      .then((response) => {
        if (response.status === 200) {
          setInsurance(response.data.files);
        } else {
          console.error("Failed to fetch files from the backend");
        }
      })
      .catch((error) => {
        console.error("Error fetching files:", error);
      });
  }, []);

  useEffect(() => {
    // Fetch the list of files when the component mounts
    axios
      .get("/api/latestinsuranceFiles", {
        headers: {
          Authorization: `Bearer ${token}`, // Include the token in the Authorization header
        },
      })
      .then((response) => {
        if (response.status === 200) {
          setInsuranceLatest(response.data.files);
        } else {
          console.error("Failed to fetch files from the backend");
        }
      })
      .catch((error) => {
        console.error("Error fetching files:", error);
      });
  }, []);

  useEffect(() => {
    // Fetch the list of files when the component mounts
    axios
      .get("/api/listMarketingFiles", {
        headers: {
          Authorization: `Bearer ${token}`, // Include the token in the Authorization header
        },
      })
      .then((response) => {
        if (response.status === 200) {
          setMarketing(response.data.files);
        } else {
          console.error("Failed to fetch files from the backend");
        }
      })
      .catch((error) => {
        console.error("Error fetching files:", error);
      });
  }, []);

  useEffect(() => {
    // Fetch the list of files when the component mounts
    axios
      .get("/api/latestmarketingFiles", {
        headers: {
          Authorization: `Bearer ${token}`, // Include the token in the Authorization header
        },
      })
      .then((response) => {
        if (response.status === 200) {
          setMarketingLatest(response.data.files);
        } else {
          console.error("Failed to fetch files from the backend");
        }
      })
      .catch((error) => {
        console.error("Error fetching files:", error);
      });
  }, []);

  // Array of tab names
  const tabNames = [
    "Profile",
    "Hybrid Selection",
    "Seeding Rate",
    "Nitrogen Management",
    "Irrigation Management",
    "Insurance Selection",
    "Marketing Options",
    "Bulletin",
  ];

  // Function to handle tab selection
  const handleTabChange = (event, newValue) => {
    setSelectedTab(newValue);
  };

  useEffect(() => {
    // Fetch the list of files when the component mounts
    axios
      .get("/api/listFiles", {
        headers: {
          Authorization: `Bearer ${token}`, // Include the token in the Authorization header
        },
      })
      .then((response) => {
        if (response.status === 200) {
          setFiles(response.data.files);
        } else {
          console.error("Failed to fetch files from the backend");
        }
      })
      .catch((error) => {
        console.error("Error fetching files:", error);
      });
  }, []);

  const handleLogout = () => {
    // Clear localStorage or sessionStorage as needed
    localStorage.clear(); // or sessionStorage.clear();

    // Redirect to the login page
    window.location.href = "/login"; // Adjust the path as needed
  };

  return (
    <div>
      {/* <div >//style={{ display: "flex" }}> */}
      <div>
        <Container maxWidth="100%">
          <Paper
            elevation={3}
            style={{ marginRight: "16px", overflow: "hidden" }}
          >
            <Tabs
              value={selectedTab}
              onChange={handleTabChange}
              indicatorColor="secondary"
              textColor="primary"
              variant="scrollable" // Enable scrollable tabs
              scrollButtons="auto" // Show scroll buttons automatically when needed
              allowScrollButtonsMobile // Allow scroll buttons on mobile devices
            >
              {tabNames.map((tab, index) => (
                <Tab
                  key={index}
                  label={tab}

                  // Removed sx prop for simplicity, adjust if needed
                />
              ))}
            </Tabs>
          </Paper>
          {/* <Paper elevation={3} style={{ marginRight: "16px" }}>
            <Tabs
              value={selectedTab}
              onChange={handleTabChange}
              indicatorColor="secondary"
              //variant="scrollable"
              textColor="primary"
              variant="fullWidth"
              //orientation="vertical" // Set tabs to be vertical
            >
              {tabNames.map((tab, index) => (
                <Tab
                  key={index}
                  label={tab}
                  sx={{ alignItems: "flex-start" }}
                />
              ))}
            </Tabs>
          </Paper> */}
          {/* Render the content for the selected tab */}
          <div>
            {/* <h2>Welcome, {username}!</h2> */}

            <Container maxWidth="100%">
              {/* <Typography variant="h5" alignContent={"center"}>
                Welcome, {username}!
              </Typography> */}
              <br></br>
              {/* <Typography variant="h5" alignContent={"center"}>
                {tabNames[selectedTab]}
              </Typography> */}
              <Box
                display="flex"
                alignItems="center"
                justifyContent="space-between"
                p={2}
                boxShadow={1}
              >
                <Typography variant="h5">{tabNames[selectedTab]}</Typography>
                <Button
                  variant="contained"
                  color="primary"
                  onClick={handleLogout}
                >
                  Logout
                </Button>
              </Box>
              {selectedTab === 0 && (
                <div
                  style={{
                    backgroundImage:
                      "url('https://step.ifas.ufl.edu/media/stepifasufledu/images/banner-photos/DJI_0265-(002).JPG')",
                    backgroundSize: "cover",
                    backgroundPosition: "center",
                    backgroundRepeat: "no-repeat",

                    justifyContent: "center", // This centers the form vertically
                  }}
                >
                  <Container>
                    <Paper elevation={3} style={{ padding: 20, margin: 20 }}>
                      <Box display="flex" alignItems="center">
                        <Avatar
                          alt="Profile Image"
                          src={profileImageUrl}
                          style={{ marginRight: 20 }}
                        />
                        <Typography variant="h4" gutterBottom>
                          Welcome, {username}!
                        </Typography>
                      </Box>
                    </Paper>
                    <Paper elevation={3} style={{ padding: 20, margin: 20 }}>
                      <Typography variant="h5" gutterBottom>
                        User Details
                      </Typography>
                      <p></p>
                      <div>
                        <Avatar
                          alt="Profile Image"
                          src={profileImageUrl}
                          sx={{ width: 350, height: 350 }}
                          variant="rounded"
                        />
                        <p></p>
                        {/* <form onSubmit={handleUpload}>
                        <input type="file" onChange={handleFileChange} />
                        <p></p>
                        <button type="submit">Upload Profile Image</button>
                        <p></p>
                      </form> */}
                        <form
                          onSubmit={handleUpload}
                          style={{
                            display: "flex",
                            flexDirection: "column",
                            gap: "20px",
                            alignItems: "start",
                          }}
                        >
                          <FormControl>
                            <InputLabel htmlFor="file-input">
                              Profile Image
                            </InputLabel>
                            <p></p>
                            <Input
                              marginLeft="40px"
                              id="file-input"
                              type="file"
                              onChange={handleFileChange}
                            />
                            <FormHelperText>
                              Select your profile image(* jpg,jpeg,png format)
                            </FormHelperText>
                          </FormControl>

                          <Button
                            variant="contained"
                            color="primary"
                            type="submit"
                          >
                            Upload Profile Image
                          </Button>
                        </form>
                      </div>
                      <Grid container spacing={3}>
                        {cornuser.length > 0 && (
                          <React.Fragment>
                            <Grid item xs={6}>
                              <Card>
                                <CardContent>
                                  <p></p>
                                  <Typography variant="h6">
                                    User Information
                                  </Typography>

                                  <Typography>
                                    Username/TeamName: {cornuser[0].teamName}
                                  </Typography>
                                  <Typography>
                                    Crop Type: {cornuser[0].cropType}
                                  </Typography>
                                  <Typography>
                                    Capitan First Name:{" "}
                                    {cornuser[0].captainFirstName}
                                  </Typography>
                                  <Typography>
                                    Capitan Last Name:{" "}
                                    {cornuser[0].captainLastName}
                                  </Typography>
                                </CardContent>
                              </Card>
                            </Grid>
                            <Grid item xs={6}>
                              <Card>
                                <CardContent>
                                  <Typography variant="h6">Location</Typography>
                                  <Typography>
                                    Address 1: {cornuser[0].address1}
                                  </Typography>
                                  <Typography>
                                    Address 2: {cornuser[0].address2}
                                  </Typography>

                                  <Typography>
                                    City: {cornuser[0].city}
                                  </Typography>
                                  <Typography>
                                    State: {cornuser[0].state}
                                  </Typography>
                                  <Typography>
                                    Zip Code: {cornuser[0].zipCode}
                                  </Typography>
                                  <Typography>
                                    Country: {cornuser[0].country}
                                  </Typography>
                                </CardContent>
                              </Card>
                            </Grid>
                            <Grid item xs={12}>
                              <Card>
                                <CardContent>
                                  <Typography variant="h6">
                                    Contact Information
                                  </Typography>
                                  <Typography>
                                    Email: {cornuser[0].email}
                                  </Typography>
                                  <Typography>
                                    Phone: {cornuser[0].phone}
                                  </Typography>
                                </CardContent>
                              </Card>
                            </Grid>
                          </React.Fragment>
                        )}
                      </Grid>
                      {teamMembers.length > 0 && (
                        <Paper
                          elevation={3}
                          style={{ marginTop: 20, padding: 20 }}
                        >
                          <Typography variant="h5" gutterBottom>
                            Team Members
                          </Typography>
                          {teamMembers.map((member, index) => (
                            <Card key={index} style={{ marginBottom: 10 }}>
                              <CardContent>
                                <Typography variant="h6">
                                  Team Member {index + 1}
                                </Typography>
                                <Typography>Name: {member.name}</Typography>
                                <Typography>Email: {member.email}</Typography>
                              </CardContent>
                            </Card>
                          ))}
                        </Paper>
                      )}
                    </Paper>
                  </Container>
                </div>
              )}
              {selectedTab === 1 && (
                <Container maxWidth="100%">
                  <div>
                    {/* <h3>Hybrid Selection</h3> */}
                    <p>
                      Hybrid selection is a critical step in crop management. It
                      involves choosing the most suitable hybrid varieties for
                      your farming conditions and goals.
                    </p>
                    <p>
                      You can choose one of the default hybrids listed below or
                      source your own seed. If sourcing your own seed,15 lbs of
                      seed must be delivered to the North Florida Research and
                      Education Center two weeks prior to planting. You must
                      provide documentation of the retail price for any seed
                      that you source.
                    </p>
                    <HybridForm />
                  </div>
                </Container>
              )}
              {selectedTab === 2 && (
                <Container component="main" maxWidth="90%">
                  <div>
                    <p>
                      Choose any plant population (seeding rate per acre)
                      between 26K and 36K, in increments of 2K.
                    </p>
                    <SeedingRateForm />
                  </div>
                </Container>
              )}
              {selectedTab === 3 && (
                <Container component="main" maxWidth="90%">
                  <div>
                    <p>
                      All the plots will receive 13 gals/ac (30 lbs/ac of N) of
                      startup fertilizer (23-9-0) at the time of planting. You
                      can choose in-season fertilizer applications of dry
                      ammonium nitrate (34-0-0) and UAN 28% (28-0-0-5), or a
                      controlled release fertilizer program.
                    </p>

                    <NitrogenManagementForm />
                  </div>
                </Container>
              )}
              {selectedTab === 4 && (
                <Container component="main" maxWidth="90%">
                  <div>
                    {/* <p>You have three options for irrigation management:</p>
                <ol>
                  <li>Soil moisture-based irrigation scheduling,</li>
                  <li>Evapotranspiration based irrigation scheduling,</li>
                  <li>Pre-determined calendar-based irrigation scheduling.</li>
                </ol> */}

                    <IrrigationManagementForm />
                  </div>
                </Container>
              )}
              {selectedTab === 5 && (
                <Container component="main" maxWidth="90%">
                  <div>
                    <p>
                      You must select crop insurance at the 50% level or above.
                      Crop insurance options include Revenue Protection and
                      Yield Protection plans. You can find more information
                      about crop insurance on the{" "}
                      <a
                        href="https://www.usda.gov/"
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        USDA website
                      </a>{" "}
                      or by contacting your local insurance agent.
                    </p>

                    <p>
                      You may choose the following coverage levels: 50%, 55%,
                      60%, 65%, 70%, 75%, 80%, or 85%. Insurance selections must
                      be made by March 31st. Once your insurance choice has been
                      submitted, it cannot be changed for this year’s contest.
                    </p>
                    <div style={{ display: "flex", flexWrap: "wrap" }}>
                      <div style={{ flex: 3, minWidth: "400px" }}>
                        <InsuranceSelectionForm />
                      </div>
                      {/* <div
                        style={{
                          flex: 1,
                          border: "1px solid #ccc",
                          padding: "10px",
                          maxHeight: "400px", // Set a maximum height for the div
                          overflow: "auto", // Add scrollbars if the content exceeds the height
                          minWidth: "300px", // Use a minimum width
                          backgroundImage: `url(${cornImage})`, // Replace 'imageUrl' with your image URL
                          backgroundSize: "cover", // Ensure the background image covers the entire div
                          backgroundPosition: "center", // Center the background image
                          backgroundRepeat: "no-repeat",
                        }}
                      >
                        <h3>List of Latest Insurance Files:</h3>

                        {insuranceLatest
                          .filter((fileName) => fileName !== "metadata.json")
                          .filter((fileName) => fileName !== "profile.jpg")
                          .length > 0 ? (
                          <>
                            {insuranceLatest
                              .filter(
                                (fileName) => fileName !== "metadata.json"
                              )
                              .filter((fileName) => fileName !== "profile.jpg")
                              .map((fileName, index) => (
                                <div
                                  key={index}
                                  style={{
                                    backgroundColor:
                                      "rgba(255, 255, 255, 0.45)",
                                    width: "100%",
                                  }}
                                >
                                  <p>File Name: {fileName.originalFileName}</p>
                                  <p>
                                    Upload Date:{" "}
                                    {new Date(
                                      fileName.uploadDate
                                    ).toLocaleDateString()}
                                  </p>

                                  <a
                                    href={`/api/downloadFile/${fileName.originalFileName}`}
                                    download
                                  >
                                    Download
                                  </a>
                                </div>
                              ))}
                          </>
                        ) : (
                          <p
                            style={{
                              backgroundColor: "rgba(255, 255, 255, 0.8)",
                            }}
                          >
                            No latest files.
                          </p> // Semi-transparent background for text readability
                        )}
                      </div> */}

                      <div
                        style={{
                          flex: 1,
                          border: "1px solid #ccc",
                          padding: "20px", // Increased padding for better spacing
                          maxHeight: "400px",
                          overflow: "auto",
                          minWidth: "300px",
                          backgroundImage: `url(${cornImage})`, // Assuming 'cornImage' is a variable holding the image URL
                          backgroundSize: "cover",
                          backgroundPosition: "center",
                          backgroundRepeat: "no-repeat",
                          borderRadius: "5px", // Added rounded corners for a softer look
                          boxShadow: "0 2px 4px rgba(0,0,0,0.1)", // Subtle shadow for depth
                        }}
                      >
                        <h3
                          style={{
                            textAlign: "center",
                            margin: "0 0 20px 0",
                            backgroundColor: "rgba(255, 255, 255, 0.3)",
                          }}
                        >
                          List of Latest Insurance Files:
                        </h3>

                        {insuranceLatest.filter(
                          (fileName) =>
                            fileName !== "metadata.json" &&
                            fileName !== "profile.jpg"
                        ).length > 0 ? (
                          insuranceLatest
                            .filter(
                              (fileName) =>
                                fileName !== "metadata.json" &&
                                fileName !== "profile.jpg"
                            )
                            .map((fileName, index) => (
                              <div
                                key={index}
                                style={{
                                  backgroundColor: "rgba(255, 255, 255, 0.8)",
                                  padding: "10px",
                                  margin: "10px 0",
                                  borderRadius: "5px", // Consistency in border radius
                                  boxShadow: "0 1px 3px rgba(0,0,0,0.1)", // Each item has a subtle shadow
                                }}
                              >
                                <p style={{ margin: "0 0 10px 0" }}>
                                  File Name: {fileName.originalFileName}
                                </p>
                                <p style={{ margin: "0 0 10px 0" }}>
                                  Upload Date:{" "}
                                  {new Date(
                                    fileName.uploadDate
                                  ).toLocaleDateString()}
                                </p>

                                <Button
                                  variant="contained"
                                  color="primary"
                                  size="small"
                                  href={`/api/downloadInsuranceFile/${fileName.originalFileName}`}
                                  download
                                >
                                  Download
                                </Button>
                              </div>
                            ))
                        ) : (
                          <p
                            style={{
                              backgroundColor: "rgba(255, 255, 255, 0.8)",
                              textAlign: "center",
                              padding: "10px",
                              borderRadius: "5px",
                            }}
                          >
                            No latest files.
                          </p>
                        )}
                      </div>
                    </div>
                  </div>
                </Container>
              )}
              {selectedTab === 6 && (
                <Container component="main" maxWidth="90%">
                  <div>
                    <div style={{ display: "flex", flexWrap: "wrap" }}>
                      <div style={{ flex: 3, minWidth: "400px" }}>
                        <p>
                          Each team must make marketing selections for the
                          simulated 1,000-acre farm. The total number of bushels
                          marketed will be the average yield per acre harvested
                          from your research plots times 1,000 acres. Simulated
                          delivery of the harvested grain corn is assumed to
                          take place on the research plot harvest date, which
                          will be in August or early September. No postharvest
                          (storage) marketing is allowed for this competition.
                        </p>

                        <p>
                          You may choose flat-price or basis contracts (for
                          August/September delivery) between the competition
                          start date and July 29th. The local basis for forward
                          contracts (relative to the Chicago Board of Trade
                          September or December futures price) will be posted
                          weekly on this webpage (see Contract Price attachment
                          below). Click the plus (+) icon in the table below to
                          choose the contract type and the number of bushels to
                          contract (in 10,000-bushel increments). You may select
                          multiple contracts, but the total amount contracted
                          (sum of all contracts) may not exceed 250,000 bushels.
                          Your previous contracts will be shown in the table
                          below.
                        </p>

                        <p>
                          For each basis contract selected, you must go to the
                          table and click the green check box in the Complete
                          column on the date you want to complete the contract
                          (lock in the futures price). If a contract is not
                          completed by July 29th, we will use the July 29th
                          closing September futures price to complete the
                          contract.
                        </p>

                        <p>
                          The grower’s delivered price on a flat contract will
                          be the sum of the local basis plus the September
                          futures closing price on the date you select the
                          contract. The grower’s delivered price on a basis
                          contract will be the sum of the local basis on the
                          date you select (initiate) the contract plus the
                          September futures closing price on the date you
                          complete the contract. A $0.30/bu hauling fee will be
                          charged for delivery to a Suwannee Valley buying
                          point.
                        </p>

                        <p>
                          Any bushels not sold through contracts (total bushels
                          harvested for the simulated 1,000-acre farm minus the
                          number of bushels contracted) will be “sold” at the
                          cash spot price on the date of harvest. If more
                          bushels are contracted than harvested, a charge to
                          purchase the extra bushels will be applied, plus a
                          $0.20/bu handling fee.
                        </p>
                      </div>
                      <p></p>

                      <div
                        style={{
                          flex: 1,
                          border: "1px solid #ccc",
                          padding: "20px", // Increased padding for better spacing
                          maxHeight: "400px",
                          overflow: "auto",
                          minWidth: "250px",
                          backgroundImage: `url(${cornImage})`, // Ensure 'cornImage' is the correct variable for the image URL
                          backgroundSize: "cover",
                          backgroundPosition: "center",
                          backgroundRepeat: "no-repeat",
                          borderRadius: "5px", // Added rounded corners
                          boxShadow: "0 2px 4px rgba(0,0,0,0.1)", // Subtle shadow for depth
                        }}
                      >
                        <h3
                          style={{
                            textAlign: "center",
                            margin: "0 0 20px 0",
                            backgroundColor: "rgba(255, 255, 255, 0.3)",
                          }}
                        >
                          List of Marketing Files:
                        </h3>

                        {marketingLatest.filter(
                          (fileName) =>
                            fileName !== "metadata.json" &&
                            fileName !== "profile.jpg"
                        ).length > 0 ? (
                          marketingLatest
                            .filter(
                              (fileName) =>
                                fileName !== "metadata.json" &&
                                fileName !== "profile.jpg"
                            )
                            .map((fileName, index) => (
                              <div
                                key={index}
                                style={{
                                  backgroundColor: "rgba(255, 255, 255, 0.8)",
                                  padding: "10px",
                                  margin: "10px 0",
                                  borderRadius: "5px", // Consistency in border radius
                                  boxShadow: "0 1px 3px rgba(0,0,0,0.1)", // Each item has a subtle shadow
                                }}
                              >
                                <p style={{ margin: "0 0 10px 0" }}>
                                  File Name: {fileName.originalFileName}
                                </p>
                                <p style={{ margin: "0 0 10px 0" }}>
                                  Upload Date:{" "}
                                  {new Date(
                                    fileName.uploadDate
                                  ).toLocaleDateString()}
                                </p>

                                <Button
                                  variant="contained"
                                  color="primary"
                                  size="small"
                                  href={`/api/downloadMarketingFile/${fileName.originalFileName}`}
                                  download
                                >
                                  Download
                                </Button>
                              </div>
                            ))
                        ) : (
                          <p
                            style={{
                              backgroundColor: "rgba(255, 255, 255, 0.8)",
                              textAlign: "center",
                              padding: "10px",
                              borderRadius: "5px",
                            }}
                          >
                            No latest files.
                          </p>
                        )}
                      </div>
                    </div>
                    <MarketingOptionsForm />
                  </div>
                </Container>
              )}
              {selectedTab === 7 && (
                <Container component="main" maxWidth="90%">
                  <p></p>
                  {/* <div>
                    <h3>List of Files in Uploads Folder:</h3>
                    <ul>
                      {files.map((fileName, index) => (
                        <li key={index}>
                          {fileName}{" "}
                          <a
                            href={`/api/downloadFile/${fileName}`}
                            download
                          >
                            Download
                          </a>
                        </li>
                      ))}
                    </ul>
                  </div> */}
                  <CornBulletin />
                </Container>
              )}
            </Container>
          </div>
        </Container>
      </div>
    </div>
  );
}

export default Welcome;
