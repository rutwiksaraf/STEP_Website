const express = require("express");
const router = express.Router();
const { setupDatabase } = require("./database");

// Define a route for inserting marketing options
router.post("/cottoninsertMarketingOption", (req, res) => {
  setupDatabase()
    .then((db) => {
      try {
        // Extract data from the request body
        const { teamName, date, contractType, quantityBushels, complete } =
          req.body;

        // Insert a new marketing option
        const insertQuery =
          "INSERT INTO cotton_marketing_options (teamName, date, contractType, quantityBushels,complete) VALUES (?, ?, ?, ?,?)";
        db.query(
          insertQuery,
          [teamName, date, contractType, quantityBushels, complete],
          (insertError, insertResult) => {
            if (insertError) {
              console.error(
                "Error inserting marketing option into the database:",
                insertError
              );
              res.status(500).json({ message: "Option insertion failed" });
            } else {
              res.status(200).json({
                message: "Option inserted successfully",
              });
            }
          }
        );
        db.release();
      } catch (error) {
        console.error("Error handling marketing option insertion:", error);
        res.status(500).json({ message: "Internal server error" });
        db.release();
      }
    })
    .catch((err) => {
      console.error("Database setup error: " + err.message);
      res.status(500).json({ message: "Database setup error" });
    });
});

// Define a route for fetching marketing options
router.get("/cottonfetchMarketingOptions", (req, res) => {
  setupDatabase()
    .then((db) => {
      try {
        // Extract the teamName from the query parameters
        const { teamName } = req.query;

        // Query the database to fetch all marketing options for the specified teamName
        const query =
          "SELECT * FROM cotton_marketing_options WHERE teamName = ?";
        db.query(query, [teamName], (error, results) => {
          if (error) {
            console.error("Error fetching marketing options:", error);
            res.status(500).json({ message: "Error fetching options" });
          } else {
            // Send the fetched data as a JSON response
            res.status(200).json(results);
          }
        });
        db.release();
      } catch (error) {
        console.error("Error handling marketing options fetch:", error);
        res.status(500).json({ message: "Internal server error" });
        db.release();
      }
    })
    .catch((err) => {
      console.error("Database setup error: " + err.message);
      res.status(500).json({ message: "Database setup error" });
    });
});

router.get("/cottonfetchAllMarketingOptions", (req, res) => {
  setupDatabase()
    .then((db) => {
      try {
        // Extract the teamName from the query parameters
        // Query the database to fetch all marketing options for the specified teamName
        const query = "SELECT * FROM cotton_marketing_options";
        db.query(query, (error, results) => {
          if (error) {
            console.error("Error fetching marketing options:", error);
            res.status(500).json({ message: "Error fetching options" });
          } else {
            // Send the fetched data as a JSON response
            res.status(200).json(results);
          }
        });
        db.release();
      } catch (error) {
        console.error("Error handling marketing options fetch:", error);
        res.status(500).json({ message: "Internal server error" });
        db.release();
      }
    })
    .catch((err) => {
      console.error("Database setup error: " + err.message);
      res.status(500).json({ message: "Database setup error" });
    });
});

router.post("/updateCompleted/:appId", async (req, res) => {
  const appId = req.params.appId; // Extract the application ID from the request parameters
  const newCompleteValue = "yes"; // Define the new value for the "complete" field
  const today = new Date().toISOString().slice(0, 10); // Get today's date in YYYY-MM-DD format

  if (!appId) {
    return res.status(400).json({ message: "Application ID is required" });
  }

  try {
    const pool = await setupDatabase(); // Obtain a connection pool
    const request = pool.request(); // Create a new request object

    // Add parameters to your SQL query
    request.input("newCompleteValue", sql.VarChar, newCompleteValue);
    request.input("today", sql.Date, today);
    request.input("appId", sql.Int, appId);

    // Perform the database update operation
    await request.query(`
      UPDATE cotton_marketing_options 
      SET complete = @newCompleteValue, completedon = @today 
      WHERE id = @appId
    `);

    res.status(200).json({ message: "Record updated successfully" });
  } catch (updateError) {
    console.error("Error updating the record:", updateError);
    res.status(500).json({ message: "Error updating the record" });
  }
});

module.exports = router;
