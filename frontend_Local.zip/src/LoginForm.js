import React, { useState, useEffect } from "react";
import {
  TextField,
  Button,
  Container,
  Typography,
  Select,
  MenuItem,
  InputLabel,
  FormControl,
  CardActionArea,
  Card,
  CardContent,
  Alert,
} from "@mui/material";
import axios from "axios";
// import { Snackbar, Alert } from "@mui/material";

function LoginForm() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [cropType, setCropType] = useState("corn"); // Default value: "corn"
  const [errorMessage, setErrorMessage] = useState("");
  const [openSnackbar, setOpenSnackbar] = useState(false);

  const handleCardClick = (type) => {
    setCropType(type);
  };

  const cropOptions = [
    { label: "Corn", value: "corn" },
    { label: "Cotton", value: "cotton" },
    // Add more options here
  ];

  useEffect(() => {
    let timer;
    if (errorMessage) {
      timer = setTimeout(() => {
        setErrorMessage("");
      }, 5000);
    }
    return () => clearTimeout(timer); // Cleanup timeout
  }, [errorMessage]);

  const handleSubmit = (e) => {
    e.preventDefault();

    // Prepare the data to send to the backend
    const formData = {
      username,
      password,
      cropType,
    };

    // Send form data to the backend using Axios
    axios
      .post("/api/login", formData) // Replace with your backend URL
      .then((response) => {
        console.log("Response from server:", response.data);

        if (response.data.message === "Login successful") {
          // Store session variables in localStorage
          localStorage.setItem("username", response.data.user.teamName);
          localStorage.setItem("cropType", response.data.user.cropType);
          localStorage.setItem("token", response.data.token);
          localStorage.setItem("username", response.data.user.teamName);
          localStorage.setItem("cropType", response.data.user.cropType);
          localStorage.setItem("token", response.data.token);

          // Redirect to the welcome page
          if (cropType === "corn") {
            window.location.href = "/welcome";
          } else if (cropType === "cotton") {
            window.location.href = "/welcomecotton";
          }
        } else if (
          response.data.message === "Invalid credentials. User does not exist."
        ) {
          setErrorMessage("Invalid credentials. User does not exist.");
        } else if (
          response.data.message ===
          "Username Exists. Please check your password."
        ) {
          setErrorMessage("Invalid credentials. Please check your password.");
        } else {
          setErrorMessage(
            "Invalid credentials. Please check your username and password."
          );
        }
      })
      .catch((error) => {
        console.error("Error sending data:", error);
        if (
          error.response &&
          error.response.data &&
          error.response.data.message
        ) {
          setErrorMessage(error.response.data.message);
        } else {
          setErrorMessage("An error occurred. Please try again later.");
        }
        // Handle error or show an error message
      });
  };

  return (
    <div
      style={{
        backgroundImage:
          "url('https://step.ifas.ufl.edu/media/stepifasufledu/images/banner-photos/Coverpage-Photo-3.jpg')",
        backgroundSize: "cover",
        backgroundPosition: "center",
        backgroundRepeat: "no-repeat",
        height: "100vh", // This sets the minimum height to 100% of the viewport height
        display: "flex",
        flexDirection: "column",
        justifyContent: "center", // This centers the form vertically
      }}
    >
      <Container component="main" maxWidth="md">
        <div className="registration-container">
          <div className="registration-form">
            <Typography variant="h3" className="loginHeading" color="primary">
              Login
            </Typography>
            <p style={{ textAlign: "justify" }}></p>
            {errorMessage && (
              <Alert severity="error" style={{ marginBottom: "20px" }}>
                {errorMessage}
              </Alert>
            )}
            {/* {errorMessage && <p className="error-message">{errorMessage}</p>} */}
            <form onSubmit={handleSubmit}>
              <FormControl fullWidth>
                {/* <Select
                label="Crop Type"
                fullWidth
                value={cropType}
                onChange={(e) => setCropType(e.target.value)}
                margin="normal"
                required
              >
                <MenuItem value="corn">Corn</MenuItem>
                <MenuItem value="cotton">Cotton</MenuItem>
              </Select> */}

                <div
                  style={{
                    display: "flex", // Enables flexbox
                    flexDirection: "row", // Align children in a row
                    flexWrap: "wrap", // Allow the items to wrap as needed
                    justifyContent: "center", // Center horizontally
                    alignItems: "center", // Center vertically
                    // Set the height of the div to fill the viewport height
                  }}
                >
                  {cropOptions.map((option) => (
                    <Card
                      key={option.value}
                      onClick={() => handleCardClick(option.value)}
                      style={{ width: 200, margin: 10, alignContent: "middle" }}
                      sx={{
                        cursor: "pointer",
                        padding: "10px",
                        backgroundColor:
                          cropType === option.value ? "#fa4616" : "#D8D4D7",
                        border: "2px solid #D8D4D7", // Highlight the selected card
                        marginRight: "30px", // Add margin to separate cards
                        alignContent: "middle",
                      }}
                    >
                      <CardContent>
                        <Typography gutterBottom variant="h5" component="div">
                          {option.label}
                        </Typography>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </FormControl>
              <TextField
                label="Username"
                fullWidth
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                margin="normal"
                required
              />
              <TextField
                label="Password"
                type="password"
                fullWidth
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                margin="normal"
                required
              />

              <Button
                type="submit"
                variant="contained"
                color="secondary"
                fullWidth
              >
                Log In
              </Button>
            </form>
            <p style={{ textAlign: "justify" }}></p>
            {/* <p style={{ textAlign: "justify" }}>
            Not registered yet?{" "}
            <a href="/register" className="signUpLink">
              Sign up
            </a>{" "}
          </p> */}
            <div style={{ display: "flex", alignItems: "center" }}>
              <p style={{ margin: 0, marginRight: "10px" }}>
                Not registered yet?
              </p>
              {/* <a href="/register" className="signUpLink">Sign up</a> */}
              <button
                variant="outlined"
                className="signUpButton"
                size="small"
                onClick={() => (window.location.href = "/register")}
              >
                Sign up
              </button>
            </div>
            <p style={{ textAlign: "justify" }}></p>
            <p style={{ textAlign: "justify" }}>
              Admin login page :{" "}
              <a href="/adminlogin" className="signUpLink">
                Admin login
              </a>
            </p>
            {/* Add 'Forgot Password?' link */}
            <div
              style={{
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                marginTop: "10px",
              }}
            >
              <a href="/forgot-password" className="forgotpassword">
                Forgot Password?
              </a>
            </div>
          </div>
        </div>
      </Container>
    </div>
  );
}

export default LoginForm;
