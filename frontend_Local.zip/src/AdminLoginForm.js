import React, { useState } from "react";
import {
  TextField,
  Button,
  Container,
  Typography,
  Select,
  MenuItem,
  InputLabel,
  FormControl,
  CardActionArea,
  Card,
  CardContent,
} from "@mui/material";

import axios from "axios";

function AdminLoginForm() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [cropType, setCropType] = useState("corn"); // Default value: "corn"
  const [errorMessage, setErrorMessage] = useState("");

  const handleCardClick = (type) => {
    setCropType(type);
  };

  const cropOptions = [
    { label: "Corn", value: "corn" },
    { label: "Cotton", value: "cotton" },
    // Add more options here
  ];

  const handleSubmit = (e) => {
    e.preventDefault();

    // Prepare the data to send to the backend
    const formData = {
      username,
      password,
      cropType,
    };
    if (username === "Step_admin27" && password === "ufifasabe27") {
      axios
        .post("/api/superadminlogin", formData) // Replace with your backend URL
        .then((response) => {
          console.log("Response from server:", response.data);

          if (response.data.message === "Login successful") {
            // Store session variables in localStorage
            localStorage.setItem("username", username);
            localStorage.setItem("cropType", "All");
            localStorage.setItem("accessToken", response.data.accessToken);
            localStorage.setItem("token", response.data.accessToken);
            window.location.href = "/admin";
            // Redirect to the welcome page
          }
        });
      //window.location.href = "/admin";
    } else {
      // Send form data to the backend using Axios
      axios
        .post("/api/adminlogin", formData) // Replace with your backend URL
        .then((response) => {
          console.log("Response from server:", response.data);

          if (response.data.message === "Login successful") {
            // Store session variables in localStorage
            localStorage.setItem("username", username);
            localStorage.setItem("cropType", cropType);
            localStorage.setItem("accessToken", response.data.accessToken);
            localStorage.setItem("token", response.data.accessToken);
            // Redirect to the welcome page
            window.location.href = "/adminspage";
            // if (cropType === "corn") {
            //   window.location.href = "/cornadmin";
            // } else if (cropType === "cotton") {
            //   window.location.href = "/cottonadmin";
            // }
          } else {
            setErrorMessage("Login failed. Invalid team name or password.");
          }
        })
        .catch((error) => {
          console.error("Error sending data:", error);
          // Handle error or show an error message
        });
    }
  };

  return (
    <div
      style={{
        backgroundImage:
          "url('https://step.ifas.ufl.edu/media/stepifasufledu/images/banner-photos/Coverpage-Photo-3.jpg')",
        backgroundSize: "cover",
        backgroundPosition: "center",
        backgroundRepeat: "no-repeat",
        height: "100vh", // This sets the minimum height to 100% of the viewport height
        display: "flex",
        flexDirection: "column",
        justifyContent: "center", // This centers the form vertically
      }}
    >
      <Container component="main" maxWidth="md">
        <div className="registration-container">
          <div className="registration-form">
            <Typography variant="h3" className="loginHeading" color="primary">
              Login
            </Typography>
            {errorMessage && <p className="error-message">{errorMessage}</p>}
            <form onSubmit={handleSubmit}>
              <FormControl fullWidth>
                {/* <InputLabel>Crop Type</InputLabel>
                <p style={{ textAlign: "justify" }}></p> */}
                <div
                  style={{
                    display: "flex",
                    flexDirection: "column", // Align children in a row
                    flexWrap: "wrap", // Allow the items to wrap as needed
                    justifyContent: "center", // Center horizontally
                    alignItems: "center",
                  }}
                >
                  {cropOptions.map((option) => (
                    <Card
                      key={option.value}
                      onClick={() => handleCardClick(option.value)}
                      style={{ width: 200, margin: 10 }}
                      sx={{
                        cursor: "pointer",
                        padding: "10px",
                        backgroundColor:
                          cropType === option.value ? "#fa4616" : "#D8D4D7",
                        border: "2px solid #fa4616", // Highlight the selected card
                        marginRight: "30px", // Add margin to separate cards
                      }}
                    >
                      <CardContent>
                        <Typography gutterBottom variant="h5" component="div">
                          {option.label}
                        </Typography>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </FormControl>
              <TextField
                label="Username"
                fullWidth
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                margin="normal"
                required
              />
              <TextField
                label="Password"
                type="password"
                fullWidth
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                margin="normal"
                required
              />

              <Button
                type="submit"
                variant="contained"
                color="secondary"
                fullWidth
              >
                Log In
              </Button>
            </form>
            <p style={{ textAlign: "justify" }}></p>
            <p style={{ textAlign: "justify" }}>
              login page :{" "}
              <a href="/login" className="signUpLink">
                User login
              </a>
            </p>
            <p style={{ textAlign: "justify" }}></p>

            {/* Use anchor tag for navigation */}
          </div>
        </div>
      </Container>
    </div>
  );
}

export default AdminLoginForm;
