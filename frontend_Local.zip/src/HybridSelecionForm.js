import React, { useState, useEffect } from "react";
import {
  TextField,
  Button,
  Typography,
  TextareaAutosize,
  Grid,
  Container,
  Card, // Import Card from Material-UI
  CardContent, // Import CardContent from Material-UI
  Table,
  TableHead,
  TableRow,
  TableCell,
  TableBody,
} from "@mui/material";
import axios from "axios"; // Import Axios for making HTTP requests

function HybridForm() {
  const [hybrid, setHybrid] = useState("");
  const [cost, setCost] = useState("");
  const [notes, setNotes] = useState("");
  const [statusMsg, setStatusMsg] = useState("");
  const teamName = localStorage.getItem("username");
  const [submittedForms, setSubmittedForms] = useState([]);
  const token = localStorage.getItem("token");

  const hybridOptions = [
    "DEKALB 68-35 /MSRP $400",
    "DEKALB 70-45 /MSRP $394",
    "Dyna-Gro (Nutrien) 57VC51 /MSRP $300",
    "Dyna-Gro (Nutrien) D58SS65 /MSRP $300",
    "INTEGRA 6641SS /MSRP $346",
    "NK1838-3110 /MSRP $340",
    "NK1677-3110 /MSRP $350",
    "Pioneer P1622VYHR /MSRP $397",
    "Pioneer P1608YHR /MSRP $390",
    "Pioneer P17677YHR /MSRP $400",
    "Pioneer P2042VYHR /MSRP $372",
    "REVERE1839 /MSRP $360",
    "Agritech 704vt2p /MSRP $315",
    "Agritech 85VT2P /MSRP $285",
    "Others",
  ];

  const hybridCosts = {
    "DEKALB 68-35 /MSRP $400": 400.0,
    "DEKALB 70-45 /MSRP $394": 394.0,
    "Dyna-Gro (Nutrien) 57VC51 /MSRP $300": 300.0,
    "Dyna-Gro (Nutrien) D58SS65 /MSRP $300": 300.0,
    "INTEGRA 6641SS /MSRP $346": 346.0,
    "NK1838-3110 /MSRP $340": 340.0,
    "NK1677-3110 /MSRP $350": 350.0,
    "Pioneer P1622VYHR /MSRP $397": 397,
    "Pioneer P1608YHR /MSRP $390": 390,
    "Pioneer P17677YHR /MSRP $400": 400,
    "Pioneer P2042VYHR /MSRP $372": 372.0,
    "REVERE1839 /MSRP $360": 360.0,
    "Agritech 704vt2p /MSRP $315": 315.0,
    "Agritech 85VT2P /MSRP $285": 285.0,

    // Assuming 'Others' does not have a predefined cost
    Others: "",
  };

  const handleHybridClick = (selectedHybrid) => {
    setHybrid(selectedHybrid);
    if (selectedHybrid !== "Others" && hybridOptions.includes(selectedHybrid)) {
      // Set cost from the hybridCosts map
      const selectedCost = hybridCosts[selectedHybrid];
      setCost(selectedCost ? selectedCost.toString() : "");
    } else {
      // Reset or handle cost for 'Others' or unlisted options
      setCost("");
    }
  };

  const fetchSubmittedForms = async () => {
    try {
      const username = localStorage.getItem("username");
      const response = await axios.post(
        "/api/getCornHybridSubmittedForms",
        { username }, // Send username as part of the request body
        {
          headers: {
            Authorization: `Bearer ${token}`, // Include the token in the Authorization header
          },
        }
      );

      if (response.status === 200) {
        // Update the state with the fetched data
        setSubmittedForms(response.data);
      } else {
        console.error("Failed to fetch submitted forms data");
      }
    } catch (error) {
      console.error("Error fetching submitted forms data:", error);
    }
  };

  useEffect(() => {
    // Fetch the submitted forms data for the logged-in user

    // Call the fetch function when the component mounts
    fetchSubmittedForms();
  }, []);

  const handleFormSubmit = async (e) => {
    e.preventDefault();

    // Prepare the data to be sent to the backend
    const formData = {
      hybrid,
      cost,
      notes,
      teamName,
    };

    try {
      // Make an HTTP POST request to your backend API using Axios
      const response = await axios.post(
        "/api/cornhybridsubmit", // Replace with your actual backend URL
        formData,
        {
          headers: {
            Authorization: `Bearer ${token}`, // Include the token in the Authorization header
          },
        }
      );

      if (response.status === 200) {
        // Form submission was successful
        fetchSubmittedForms();
        setStatusMsg("Form submitted successfully");
      } else {
        // Form submission failed
        setStatusMsg("Form submission failed");
      }
    } catch (error) {
      console.error("Error submitting the form:", error);
      setStatusMsg("Form submission failed");
    }
  };

  return (
    <Container>
      <Grid item xs={12}>
        <Typography variant="h5">Hybrids to use:</Typography>
        {/* <div style={{ display: "flex", flexWrap: "wrap" }}>
          {hybridOptions.map((option) => (
            <Card
              key={option}
              onClick={() => handleHybridClick(option)}
              sx={{
                cursor: "pointer",
                margin: "4px",
                padding: "8px",
                backgroundColor: hybrid === option ? "#fa4616" : "white", // Highlight the selected card
              }}
            >
              <CardContent>
                <Typography variant="body2">{option}</Typography>
              </CardContent>
            </Card>
          ))}
        </div> */}

        <div style={{ display: "flex", flexWrap: "wrap" }}>
          {hybridOptions.map((option) => (
            <Card
              key={option}
              onClick={() => handleHybridClick(option)}
              sx={{
                cursor: "pointer",
                margin: "4px",
                padding: "8px",
                backgroundColor: hybrid === option ? "#fa4616" : "#D8D4D7", // Color for selected and unselected cards
                border: "2px solid #fa4616", // Border for all cards
                borderRadius: "8px", // Rounded corners
                color: hybrid === option ? "white" : "black", // Text color
              }}
            >
              <CardContent>
                <Typography variant="body2">{option}</Typography>
              </CardContent>
            </Card>
          ))}
        </div>
      </Grid>
      <Typography variant="h4" gutterBottom>
        My Form
      </Typography>
      <form onSubmit={handleFormSubmit}>
        <Grid container spacing={2}>
          <Grid item xs={12}>
            <Typography variant="h6">
              <label
                style={{
                  display: "inline-block",
                  marginRight: "16px",
                  alignContent: "center",
                }}
              >
                Hybrid
              </label>
            </Typography>
          </Grid>
          <Grid item xs={12}>
            <TextField
              id="hybrid-input"
              label="Hybrid"
              variant="outlined"
              fullWidth
              value={hybrid}
              onChange={(e) => setHybrid(e.target.value)}
              placeholder="Hybrid"
              required
            />
          </Grid>

          <Grid item xs={12}>
            {hybrid === "Others" || !hybridOptions.includes(hybrid) ? (
              <>
                <TextField
                  id="cost-input"
                  label="Cost"
                  variant="outlined"
                  fullWidth
                  value={cost}
                  onChange={(e) => setCost(e.target.value)}
                  placeholder="Cost"
                  required
                />
                <Typography variant="body2" color="textSecondary">
                  $/bag
                </Typography>
              </>
            ) : null}
          </Grid>

          <Grid item xs={12}>
            <TextField
              id="notes-input"
              label="Notes"
              variant="outlined"
              fullWidth
              multiline
              rows={4}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Notes"
            />
          </Grid>
          <Grid item xs={12}>
            <Button
              id="hybrid-selection-submit"
              variant="contained"
              color="primary"
              type="submit"
            >
              Submit
            </Button>
          </Grid>
          <Grid item xs={12} sx={{ textAlign: "right" }}>
            <Typography variant="subtitle1" id="hybrid-status-msg">
              {statusMsg}
            </Typography>
          </Grid>
        </Grid>
      </form>
      {submittedForms.length > 0 && (
        <div>
          <strong>
            {" "}
            <Typography variant="h5" gutterBottom>
              Submitted Data
              <br></br>
            </Typography>{" "}
          </strong>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>
                  <b>Hybrid</b>
                </TableCell>

                <TableCell>
                  <b>Cost per Bag</b>
                </TableCell>

                <TableCell>
                  <b>Notes</b>
                </TableCell>
                {/* <TableCell>
                    <b>Team Name</b>
                  </TableCell> */}
              </TableRow>
            </TableHead>
            <TableBody>
              {submittedForms.map((form, index) => (
                <TableRow key={index}>
                  <TableCell>{form.hybrid}</TableCell>

                  {form.hybrid === "Others" ||
                  !hybridOptions.includes(form.hybrid) ? (
                    <TableCell>${form.cost}</TableCell>
                  ) : (
                    <TableCell>
                      {hybridOptions.includes(form.hybrid)
                        ? `$${form.cost}`
                        : `$${form.cost}`}
                    </TableCell>
                  )}

                  {/* {form.hybrid === "Others" ||
                  !hybridOptions.includes(form.hybrid) ? (
                    <TableCell>Cost ${form.cost}</TableCell>
                  ) : (
                    <TableCell></TableCell>
                  )} */}

                  <TableCell>{form.notes}</TableCell>
                  {/* <TableCell>{form.teamName}</TableCell> */}
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}
    </Container>
  );
}

export default HybridForm;
